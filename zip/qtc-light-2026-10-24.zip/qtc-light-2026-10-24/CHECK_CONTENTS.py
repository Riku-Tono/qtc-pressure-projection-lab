"""Integrity check for the LIGHTWEIGHT documents, not numerical reproduction."""
import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
bad=[]
for name,row in manifest['files'].items():
    p=root/name
    if not p.is_file() or p.stat().st_size!=row['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
        bad.append(name)
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
extras=sorted(actual-set(manifest['files'])-{'MANIFEST.json'})
print(json.dumps(dict(passed=not bad and not extras,files=len(manifest['files']),mismatches=bad,unlisted=extras,scope='lightweight file integrity only'),ensure_ascii=False))
sys.exit(0 if not bad and not extras else 1)
