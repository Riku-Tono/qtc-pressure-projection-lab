EQTC着想・層厚校正 E1 — 2026-10-23
==================================

問い: E0の光学層を厚くすると、同じ精度基準を満たせるか。
成果の入口はindex.html、結論は結果.txt。E0の測定データとソースは保つ。
ChatGPT「EQTCの使い道提案」およびClaude bridgeと計画/結果を協議した。

対象と判定
----------
E0から保存済みの入力u*、fine参照phi_ref/u_refをそのままコピーし、
同じGalerkin圧力空間を使用。水平32x32、水深16/32/48セル、表層/深部、
seed0/1の12ケース。t=4..nz-2の全整数とfineを走査（計336設定）。
t>=nz-2ではすでに細格子の全圧力空間となる。これを縮約の成功と混同しない。

精度基準はE0のまま:
・入力の面体積重み付き速度ノルムに対する速度差 <= 2%
・細格子発散RMSの投影後/投影前 <= 5%
・正味表面流束 / 入力の絶対表面流束 <= 1e-8
丸める前の値で三つすべてを判定する。速度だけ良くても合格にしない。

first-pass: 走査したt>=4の範囲で最初に全条件を満たす整数。
stable-pass: それ以上の走査厚さで合格し続ける最小整数。
発散の単調減少は仮定しない。水深/入力群の共通閾値は実際の合格集合の
共通部分で求める。個別の最小値の最大を無条件に共通閾値としない。

分類: full-basis-recoveryはDOF削減なし、reduced-passはDOF削減あり。
substantial-reduction-passは事前に定めた「DOF30%以上削減」も満たすもの。
30%は本実験の記述基準であり、統計的有意差を意味しない。
ケースごとの厚さはfineとの比較で決めるオフライン校正（oracle）。
未知の将来入力から厚さを決めるオンライン適応ではない。

厚さtはセル数、物理厚はt/nx、水深に対する比率はt/nz。
背景セルは各方向h=1/nxの立方体。水平領域1x1、鉛直計算領域高2。
水深nz/32。64^3の水はh=1/64、水深1で、32^3の水と同じ物理水深。
64格子の2tセルは、32格子のtセルと同じ物理厚を保つ。

品質と費用を分ける
------------------
探索中はfine格子を再利用してよい。これは計時比較には使わない。
全厚さの解、指標、合否列、探索全体の壁時計時間を保存する。
初合格とその直前はPCG許容残差1e-10から1e-11に厳しくし、合否が
反転しないことを確認する。fine自身が不合格、全基底回復の不一致、
未収束があれば、数値計算の失敗として止め、精度未達と区別する。

計時は各ケースのfine、固定8、初合格、直前、全基底回復を対象にする。
重複した設定は一つにまとめる。ウォームアップ1回後、5ブロックで方法順を
固定seedでシャッフル。毎回fine演算子・層・基底・縮約行列・Jacobi PCG・
復元を新しく実行し、E0とバイト一致のpipelineを使う。初期解は0、
BLAS/OMPは1スレッド。電源設定は変更しない。I/O・参照・指標・保存は計時外。
探索費は別記し、総計時に混ぜない。

各ブロックの候補/fine時間比と逆数の速度比を保存。
品質合格・DOF削減あり・5回すべて候補/fine<1を満たすときのみ
「総時間短縮を反復確認」とする。それ以外も全生データを示す。
求解+復元だけの時間も表示するが、総時間と混同しない。
初合格が最速とは限らない。他の未計時の合格厚が速くならないとは結論しない。
E0の別時点の時間や原論文の時間を対照に使わない。有意差は主張しない。

追加確認
--------
静水は水深3種類でfine/t4/t(nz-3)/t(nz-2)の計12設定を確認。
64^3では既存E0の表層/深部seed0を使い、32格子の初合格tに対し
2t-2,2t,2t+2と全基底62を重複除去して品質のみ確認する。
64格子での最小合格厚、格子収束率、性能スケーリングの証拠とはしない。

再実行（このフォルダーをカレントにしたPowerShell）
------------------------------------------------
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' test_audit.py
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -u run.py
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' audit.py
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' summarize.py
  node build-report.mjs
  node serve.mjs

閲覧: http://127.0.0.1:8771/eqtc-thickness-lab/
index.htmlは保存済みのデータを読むだけで計測を開始しない。
再計測はE1のverification/を置き換える。必要ならフォルダーをコピーして実行。
E0の保存結果、入力と参照を親隣接フォルダーに必要とする。

保存構成
--------
plan.json: 計測前に固定した範囲、判定、反復、例外/停止条件。
vendor/: E0ソースのバイト一致コピー。独立検査はverify_e0だけをimportする。
verification/observations.json: 測定マニフェスト。監査/レポート作成では変更しない。
verification/runs.csv: 全厚さの品質結果。
verification/case_summaries.csv,group_summaries.csv: ケース別/群別の必要厚。
verification/timings.csv: 5反復すべての処理時間。
verification/raw/: 各解のphi、縮約係数、縮約右辺のNPZ。
verification/snapshots/: 入力・参照の共有NPZ。E0 fine保存ファイルと同一バイト。
verification/bases/: 実際に使った共有基底ids/weights/layers/dof。
各rawはsnapshot/basisと組み合わせて再計算する。重複配列は保存しない。
投影後速度は別実装で復元してproduction側の配列SHA-256と一致を確認する。
checks.json: ソルバーをimportせず行った独立再計算と網羅/閾値監査。
verification/browser-checks.json: 実ブラウザーの操作・表示・画面とソースのハッシュ。
collaboration-*.json: ChatGPT/Claudeとの協議のツール応答。
results.js: レポート用に生成した静的データ。測定ファイルとは別。

この実験からは言えないこと
------------------------
原EQTCのminimal/virtual-face離散化、水平四分木適応、移流、水面追跡、
飛沫、長期体積保存は未実施。原論文のEQTCの性能評価ではない。
fine格子を保持する縮約実装なので、DOF削減をpeakメモリ削減とは呼ばない。
同じDOFの等方粗化との比較もなく、tall方式の一般的優位性を主張しない。

関連一次資料とE0の詳細: ../eqtc-fluid-lab/README.txt
EQTC: https://graphics.c.u-tokyo.ac.jp/en/research/beyond-horizontal-refinement/
QTC Hindsight: https://graphics.c.u-tokyo.ac.jp/en/research/quadtree-tall-cells/
