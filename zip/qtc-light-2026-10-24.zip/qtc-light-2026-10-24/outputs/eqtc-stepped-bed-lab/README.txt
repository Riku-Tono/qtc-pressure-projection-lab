EQTC着想 E4 — 段差底と、強い細格子法を含む全費用比較
2026-10-23

index.html は保存結果の静的ビューアです。開いても求解・入力生成は行いません。
結果.txt と verification/cases.csv、attempts.csv、timings.csv、cost-analysis.json が集計です。
verification/observations.json は観測後固定、監査結果は checks.json へ別保存します。

対象
一回の圧力投影。nx32、nz32/48、h1/32。整数段差底を持つMAC有限体積格子。
底の3形状は step / platform / terraces。全水平列の上端は同じ平面p=0で半セル距離。
固体の底・段差壁・側壁は不透過で、その面速度を未知数に持ちません。
各列の実際の水セルだけを圧力未知数に持ち、DOF削減の分母もその水セル数です。
底は水平4x4ブロックに整列し、8x8粗モデルと対応します。非整列形状は検証していません。
旧矩形全域のtensor-product DCT直接解法は段差形状へそのまま適用できないため使用しません。
DCTを補助前処理へ使う可能性まで否定する比較ではありません。

精度条件は据え置き
速度差の面Mノルム / 入力速度Mノルム <=2%。M=face_area*distance。
体積重み付き発散前後比 <=5%、正味上端流束比 <=1e-8。
選択時は参照非依存の速度上界1.99%、発散4.99%、流束9.9e-9。
底から残留発散を積分した実行可能な補正qのノルムが厳密投影誤差の上界です。
qは判定用で、出力速度へ適用して条件を通す処理ではありません。
float64試験であり、丸め誤差を包む区間保証ではありません。
入力エネルギーの下限1e-30。通常の相対値の解釈はその下限以上の入力に限ります。

5方式と細格子比較
fine-sa: PyAMG smoothed aggregation の対称V-cycleを前処理にしたSciPy CG。
fine-rs: PyAMG classical Ruge-Stuben の対称V-cycleを前処理にしたSciPy CG。
fine-jacobi: コンパイルされたSciPy CSR行列を使うJacobi前処理CG。
predict-sa: 同じ予測から縮約候補を最大1回。不合格ならfine-saへ戻ります。
predict-jacobi: 同じ予測から縮約候補を最大1回。不合格ならfine-jacobiへ戻ります。
全CGはzero initial、rtol1e-10、atol0、maxiter1000。独立actual residual<=1.01e-10。
1%の実残差丸め幅も全CG共通です。非収束・非有限・細格子精度不合格は全比較を無効にします。
数値前処理、matrix copy、CSR整形、AMG階層、coarse factorを呼出し間で再利用しません。
PyAMG内部乱数を固定・復元し、入力生成の乱数と分離。int32 sparse index制限を検査します。
pinv coarse solverの初回factor費は初回V-cycle内のsolve区間に入り、総時計へ含まれます。

初回予測
元の入力発散を各列の底側半分で積分し、表現される面の列平均を除いたMノルムを使います。
深部指標が0.1を超えたら、粗モデルを構築する前に直接細格子へ切替。
それ以外は水平8x8×同nz、hz1/32の実段差粗モデルを作り、SuperLUで一度解きます。
各tで深部pressureを底から一次補間し、粗いエネルギーproxy<=1.99%と粗い発散proxy<=4.99%を検査。
最初の合格tへ1層を加え、実水セルのDOF削減>=40%を満たすときだけ元格子候補を試します。
深部指標・粗proxyは効率用ヒューリスティックで、元格子精度を保証しません。
元格子の参照非依存certificateと、不合格時の同backend細格子復帰で精度を守ります。
入力名、seed、family、ファイルパス、細格子参照、他方式の解は予測器へ渡しません。

固定・新入力・参照
旧E3入力と製造ケースだけで開発。SA/RSは反復数を減らした一方、旧4systemではCSR-Jacobiが総時間最短。
この事前結果で主方式をpredict-jacobiに固定し、SA/RSも新入力のbaselineへ残しました。
planと数値ソースのSHAをdeclaration.jsonへ宣言してから、初めて未使用入力を生成。
2深さ×3形状×2family×2seed401/809=24主入力、静水/curl/混合seed1201の18対照。
全42入力・5方式の全判断と試した候補をdecision-seal.jsonへ封印してから、評価参照を解きます。
参照は独立SuperLU、全6形状の因子をmatrixSHAで区別して再利用。各rhs実残差<=1e-11を検査。
参照cacheは精度評価用だけで、selector/predictorから見えません。共通に計時外です。
予測器の粗SuperLUは毎呼出し新規で、準備と求解の両方が計時内です。
新しい検証結果後の数値規則・閾値・生成器の調整はありません。

総時間と事前主判定
warmup1回＋5回順序シャッフル。入力ごとに全方式を同じ環境で計時します。
格子activeindex/面/CSR構築、全予測、粗行列/因子/求解/厚さ探索、候補基底/RAP、
backend準備/求解/実残差、再構成、全判定、棄却候補、同backend細格子復帰を全時計へ含みます。
入力生成・外部I/O・評価参照・事後metrics・SHA・保存・ブラウザ描画は共通に計時外。
各timed候補の全配列fingerprintを封印済み品質配列と一致検査します。
主24入力について各roundのSA/RS/Jacobi細格子法それぞれの総時間合計を求め、その最小を分母とします。
これは事前の集計envelopeで、実行時解法選択policyや、入力ごとの良い解法を寄せ集めた値ではありません。
成功には全42×5最終精度合格、predict-jacobiの主24入力で6件以上縮約、全5roundで対envelope比<1を要求。
同backend比較 predict-sa/fine-sa と predict-jacobi/fine-jacobi も必ず表示します。
主24入力・対照18入力・参考全42入力は分けます。全42時間は主要判定に使いません。
5回の範囲は信頼区間ではありません。3%未満差は強い性能主張を控える事前解釈帯で、ノイズ推定ではありません。
旧入力の開発計算費はplanの記録分を別に一度加算し、初回費用回収も表示します。
人的実装作業時間は未計測で、その数字には含みません。

限界
数値格子・CSR・前処理を毎回新規準備する単一圧力投影。
Python import/プロセス起動、OS・ハードウェアcache coldは計測していません。
形状・時刻間で前処理や因子を再利用する長期実行は検証していません。
E3とCSR実装や形状が異なるため過去の秒数・改善率を直接比較せず、同一新集合内の比だけを使います。
試した細格子法の最短合計との比較であり、最速な一般細格子法やAMG最適設定を主張しません。
整数段差3形状・平面上端・整列粗ブロックの条件に限り、任意形状や非一様格子へ外挿しません。
原EQTCの水平適応・最小面・仮想面、移流・水面追跡・飛沫・時間発展・長期体積は未実装です。

閲覧と検証
node serve.mjs
http://127.0.0.1:8774/eqtc-stepped-bed-lab/
保存済み監査と表示集計は、依存のあるPython/Nodeで以下を実行します。
python test_geometry.py
python test_solvers.py
python test_selector.py
python test_audit.py
python audit.py verification/observations.json
node build-report.mjs
node report-smoke.mjs
runtime: Python3.12、NumPy2.3.5、SciPy1.16.3、PyAMG5.3.0。requirements.txtを参照。
root workspaceの.eqtc-e4-depsがあればrun.pyはそこを優先して読みます。
既存の観測・宣言を上書きせず、再測定には実験フォルダを別場所へコピーし、
verificationを安全に別名へ退避した上でseal→evaluate→timingを順に実行してください。
python -u run.py --phase seal
python -u run.py --phase evaluate
python -u run.py --phase timing
過去4実験のprovenance用観測は兄弟フォルダから読みます。
規則を改良する場合は次の実験版と別の未使用入力を宣言します。

協議と監査
collaboration-*.json と collaboration.txt にChatGPT/Claudeの原応答・統合判断を保存。
両者のレビューは送信した設計・集計に対するもので、ローカルNPZ直接監査ではありません。
独立audit担当は保存配列と独立作用素で照合します。report-smokeはDOM control-flowのみで、
実ブラウザの操作とPC/スマホ描画確認は別のbrowser-checks.jsonです。

事後分析（新しい計測・規則変更なし）
補足分析.txt、posthoc-path-costs.py/json、posthoc-checks.jsonを参照。
縮約した主6件だけでも群合計は全5反復で細格子Jacobiより遅く、比中央値1.073。
元の主判定、固定数値ソース、全観測、費用集計、最終checksは変更していません。
