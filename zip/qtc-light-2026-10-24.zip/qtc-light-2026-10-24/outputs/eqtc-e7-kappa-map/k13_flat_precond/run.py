"""Stage K13: timing of the flat-bed separable preconditioner (lib/flatprec.py)
for the reduced CG on general beds (E7 step, E4 platform and terraces), against
E7's diagonal-preconditioned reduced CG, under an equal-quality condition.
Timed: Ar assembly (fresh only), preconditioner setup, CG solve, prolongation.
Reference column for the surrogate: the shallowest bed value (fixed in advance).
usage: python -I -B run.py
"""
import sys, json, time
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'lib'))
import common  # noqa
from common import sha, env_record, Geometry
from jsonsafe import write_json
import numpy as np
from scipy.sparse.linalg import splu
from time import perf_counter
import mesh, inputs as e4inputs
import k3d, fastp, placement, flatprec, redsolve as rs
import inputs_wave as iw
import inputs_variant as iv


def check_frozen():
    side = (HERE / 'declaration.sha256').read_text().split()[0]
    if sha(HERE / 'declaration.json') != side:
        raise SystemExit('declaration changed')
    decl = json.loads((HERE / 'declaration.json').read_text(encoding='utf-8'))
    bad = [p for p, h in decl['hash_links'].items() if sha(ROOT / p) != h]
    if bad:
        raise SystemExit('hash-linked files changed: ' + ', '.join(bad))
    return decl, side


def main():
    decl, dsha = check_frozen()
    out = HERE / 'results'; out.mkdir(exist_ok=False)
    rng = np.random.default_rng(decl['shuffle_seed'])
    cases = []
    for gname in decl['geometries']:
        bottom = k3d.step_bottom(12) if gname == 'step12' else e4inputs.bed(32, 48, gname)
        grid = mesh.Grid(32, 48, bottom); gl = mesh.Grid(32, 48, bottom, build_matrix=False); g = Geometry(bottom); A = grid.A
        beds = sorted(set(int(v) for v in np.unique(bottom)))
        ins = [(f'surface-s{s}', iw.generate_surface(gl, s)) for s in decl['inputs']['surface']] + \
              [(f'bulk-s{s}', iv.generate(gl, 'bulk', s)) for s in decl['inputs']['bulk']]
        for iname, us in ins:
            b = -grid.cell_volume * grid.divergence(us)
            for bname in decl['bases']:
                kc = {bb: (bb + 29) // 2 for bb in beds} if bname == 'mid' else placement.per_type(g, b)
                P = fastp.build_P_types(g, {bb: [bb, kc[bb]] + list(range(29, 48)) for bb in beds})
                Ar = (P.T @ A @ P).tocsr(); br = np.asarray(P.T @ b).ravel()
                cases.append(dict(geom=gname, input=iname, basis=bname, kc={str(k): v for k, v in kc.items()}, A=A, P=P, Ar=Ar, b=b, br=br,
                                  ref=max(beds), kc_ref=kc[max(beds)], x_lu=splu(Ar.tocsc()).solve(br), y_inv=bool(np.all(bottom == bottom[0:1, :])), bottom=bottom))
    def run(c, meth, scen, cache):
        A, P, b = c['A'], c['P'], c['b']
        t0 = perf_counter()
        if scen == 'fresh':
            Ar = (P.T @ A @ P).tocsr(); Ar.sum_duplicates(); Ar.sort_indices()
        else:
            Ar = c['Ar']
        br = np.asarray(P.T @ b).ravel(); t1 = perf_counter(); info = {}
        key = (id(c), meth)
        if meth == 'e7_cg':
            t2 = perf_counter(); x, info = rs.cg_jacobi(Ar, br)
        elif meth == 'flat_pcg':
            if scen == 'fresh' or key not in cache:
                cache[key] = flatprec.FlatPrec(c['ref'], c['kc_ref'])
            t2 = perf_counter(); x, info = rs.cg_pre(Ar, br, cache[key].solve)
        t3 = perf_counter(); p = P @ x; t4 = perf_counter()
        return x, dict(assembly_ms=(t1 - t0) * 1e3, setup_ms=(t2 - t1) * 1e3, solve_ms=(t3 - t2) * 1e3, prolong_ms=(t4 - t3) * 1e3, total_ms=(t4 - t0) * 1e3, **info)
    cache = {}; quality = []
    for c in cases:
        for meth in decl['methods']:
            for scen in decl['scenarios']:
                x, info = run(c, meth, scen, cache)
                d = x - c['x_lu']; Ar = c['Ar']
                quality.append(dict(geom=c['geom'], input=c['input'], basis=c['basis'], method=meth, scenario=scen, iterations=info.get('iterations'),
                                    reduced_rel_residual=float(np.linalg.norm(c['br'] - Ar @ x) / np.linalg.norm(c['br'])),
                                    x_Anorm_rel_err=float(np.sqrt(d @ (Ar @ d) / (c['x_lu'] @ (Ar @ c['x_lu']))))))
    print('quality done', flush=True)
    trials = []
    order0 = [(i, m, s) for i in range(len(cases)) for m in decl['methods'] for s in decl['scenarios']]
    for rnd in range(decl['rounds']):
        for i, m, s in [order0[k] for k in rng.permutation(len(order0))]:
            _, info = run(cases[i], m, s, cache)
            trials.append(dict(round=rnd, geom=cases[i]['geom'], input=cases[i]['input'], basis=cases[i]['basis'], method=m, scenario=s, **info))
        print(f'round {rnd} done', flush=True)
    write_json(out / 'k13.json', dict(declaration_sha256=dsha, env=env_record(), quality=quality, trials=trials,
                                      cases=[{k: v for k, v in c.items() if k in ('geom', 'input', 'basis', 'kc', 'ref', 'kc_ref', 'y_inv')} for c in cases]))


if __name__ == '__main__':
    main()
