"""Apply the frozen K13 rules. usage: python -I -B judge.py"""
import sys, json
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'lib'))
import numpy as np
from common import sha
from jsonsafe import write_json


def main():
    decl = json.loads((HERE / 'declaration.json').read_text(encoding='utf-8'))
    d = json.loads((HERE / 'results/k13.json').read_text(encoding='utf-8'))
    R = decl['rules']; T = d['trials']; Q = d['quality']
    rows = []
    for c in d['cases']:
        sel = lambda m, s: {t['round']: t for t in T if t['geom'] == c['geom'] and t['input'] == c['input'] and t['basis'] == c['basis'] and t['method'] == m and t['scenario'] == s}
        row = dict(geom=c['geom'], input=c['input'], basis=c['basis'])
        for s in decl['scenarios']:
            e7, fp = sel('e7_cg', s), sel('flat_pcg', s)
            row[f'{s}_ratio_median'] = float(np.median([fp[r]['total_ms'] / e7[r]['total_ms'] for r in e7]))
            row[f'{s}_e7_ms'] = float(np.median([t['total_ms'] for t in e7.values()])); row[f'{s}_flat_ms'] = float(np.median([t['total_ms'] for t in fp.values()]))
            row[f'{s}_flat_setup_ms'] = float(np.median([t['setup_ms'] for t in fp.values()]))
        q = {(x['method'], x['scenario']): x for x in Q if x['geom'] == c['geom'] and x['input'] == c['input'] and x['basis'] == c['basis']}
        row['it_e7'] = q[('e7_cg', 'fresh')]['iterations']; row['it_flat'] = q[('flat_pcg', 'fresh')]['iterations']
        rows.append(row)
    qual_ok = all(x['reduced_rel_residual'] <= R['residual'] and x['x_Anorm_rel_err'] <= R['x_err'] for x in Q)
    v = dict(T1=all(r['fresh_ratio_median'] <= R['fresh_ratio'] for r in rows), T2=all(r['it_flat'] <= R['it_ratio'] * r['it_e7'] for r in rows),
             T3=qual_ok, T4_reuse=all(r['reuse_ratio_median'] <= R['reuse_ratio'] for r in rows))
    out = dict(k13_json_sha256=sha(HERE / 'results/k13.json'), rows=rows, verdicts=v,
               worst_quality=dict(max_residual=max(x['reduced_rel_residual'] for x in Q), max_x_err=max(x['x_Anorm_rel_err'] for x in Q)))
    write_json(HERE / 'results/judgement.json', out)
    for r in rows:
        print(r['geom'], r['input'], r['basis'], 'fresh x%.3f (%.1f vs %.1f ms) reuse x%.3f | it %d vs %d' % (r['fresh_ratio_median'], r['fresh_flat_ms'], r['fresh_e7_ms'], r['reuse_ratio_median'], r['it_flat'], r['it_e7']))
    print(json.dumps(v), json.dumps(out['worst_quality']))


if __name__ == '__main__':
    main()
