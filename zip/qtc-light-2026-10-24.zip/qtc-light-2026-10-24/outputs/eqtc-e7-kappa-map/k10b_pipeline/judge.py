"""Apply the frozen K10b rules (declaration.json 'predictions'/'rules').
Written after the declaration was frozen but before the run (no result seen).
usage: python -I -B judge.py
"""
import sys, json
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'lib'))
import numpy as np
from common import sha
from jsonsafe import write_json


def main():
    decl = json.loads((HERE / 'declaration.json').read_text(encoding='utf-8'))
    d = json.loads((HERE / 'results/k10.json').read_text(encoding='utf-8'))
    R = decl['rules']; T = d['trials']; Q = d['quality']; eq = d['equivalence']
    unseen = [n for n, c in d['cases'].items() if c['family'] != 'design']
    rows = []
    for n in d['cases']:
        row = dict(input=n, family=d['cases'][n]['family'])
        for k in (0, 8):
            sel = lambda p: {t['round']: t for t in T if t['input'] == n and t['pipeline'] == p and t['k'] == k}
            e7, fm, fi, t19 = sel('e7_mid'), sel('fast_mid'), sel('fast_ic'), sel('e7_top19')
            row[f'k{k}_fastmid_over_e7'] = float(np.median([fm[r]['total_ms'] / e7[r]['total_ms'] for r in e7]))
            row[f'k{k}_fastic_over_fastmid'] = float(np.median([fi[r]['total_ms'] / fm[r]['total_ms'] for r in e7]))
            row[f'k{k}_ms'] = {p: float(np.median([t['total_ms'] for t in sel(p).values()])) for p in ('e7_mid', 'fast_mid', 'fast_ic', 'e7_top19')}
            row[f'k{k}_E'] = {p: Q[f'{n}|{p}|k{k}']['E'] for p in ('e7_mid', 'fast_mid', 'fast_ic', 'e7_top19')}
        rows.append(row)
    v = dict(Q1=all(e['fast_cg_bitwise'] for e in eq.values()),
             Q2=all(e['ydct_phi_rel'] <= R['phi_rel'] and e['ydct_E_rel'] <= R['E_rel'] for e in eq.values()),
             T1=all(r[f'k{k}_fastmid_over_e7'] <= R['t1'] for r in rows for k in (0, 8)),
             Q3=float(np.mean([r['k8_E']['fast_ic'] < r['k8_E']['e7_mid'] for r in rows if r['input'] in unseen])) >= R['q3'],
             T2=all(r[f'k{k}_fastic_over_fastmid'] <= R['t2'] for r in rows for k in (0, 8)))
    out = dict(k10_json_sha256=sha(HERE / 'results/k10.json'), rows=rows, equivalence=eq, verdicts=v)
    write_json(HERE / 'results/judgement.json', out)
    for r in rows:
        print(r['input'], 'k8: fast_mid/e7 %.3f fast_ic/fast_mid %.3f | ms %s | E fast_ic/e7 %.3f' % (r['k8_fastmid_over_e7'], r['k8_fastic_over_fastmid'],
              {k: round(x, 1) for k, x in r['k8_ms'].items()}, r['k8_E']['fast_ic'] / r['k8_E']['e7_mid']))
    print(json.dumps(v))


if __name__ == '__main__':
    main()
