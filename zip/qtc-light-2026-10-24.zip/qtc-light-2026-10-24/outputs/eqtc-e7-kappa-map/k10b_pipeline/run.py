"""Stage K10b (re-declaration after the K10 reference crash, see k10_pipeline/FAILED.md): end-to-end pressure projection on the E7 step bed, fresh scenario
(everything rebuilt per call, exactly like E7's execute()).

Pipelines (each with Jacobi post-smoothing k = 0 and 8):
  e7_mid    : E7's own execute() (vendor/e6_run.py byte copy) with basis.DepthBasis 'deep_midpoint'
  fast_mid  : the same steps and clocks re-implemented with the vectorised per-type P (lib/fastp.py)
              and the exact y-cosine reduced solver (lib/redsolve.YDCTBlock); same knots as e7_mid
  fast_ic   : as fast_mid, with the deep knots chosen per bed type by the exact-1D captured
              energy (lib/placement.per_type); the selection time is inside the clock
  e7_top19  : E7 execute() with 'top19'
Equivalence check (untimed): fast_mid with the CG solver replaced back by E7's
solvers.solve reproduces e7_mid bit for bit; fast_mid with YDCT agrees to ~1e-12.
usage: python -I -B run.py
"""
import sys, json, time, types
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'lib'))
import common  # noqa  (single-thread BLAS, deps path, vendor path)
from common import sha, env_record
from jsonsafe import write_json
import numpy as np
from scipy.sparse.linalg import splu
import mesh, basis, solvers
import e6_run as engine
import k3d, fastp, placement, redsolve as rs
import inputs_wave as iw
import inputs_variant as iv


def check_frozen():
    side = (HERE / 'declaration.sha256').read_text().split()[0]
    if sha(HERE / 'declaration.json') != side:
        raise SystemExit('declaration changed')
    decl = json.loads((HERE / 'declaration.json').read_text(encoding='utf-8'))
    bad = [p for p, h in decl['hash_links'].items() if sha(ROOT / p) != h]
    if bad:
        raise SystemExit('hash-linked files changed: ' + ', '.join(bad))
    return decl, side


class FastBasis:
    def __init__(self, g, knots_of_bed):
        self.grid = g; self.knots_of_bed = knots_of_bed
        G = types.SimpleNamespace(bottom=g.bottom, ids=g.ids, n=g.n)
        self.P = fastp.build_P_types(G, knots_of_bed)
        self.knots = tuple(np.array(sorted(set(knots_of_bed[int(g.bottom[divmod(c, 32)])]))) for c in range(1024))

    def prolong(self, p): return np.asarray(self.P @ p).reshape(-1)
    def restrict(self, p): return np.asarray(self.P.T @ p).reshape(-1)

    def assemble(self):
        r = (self.P.T @ self.grid.A @ self.P).tocsr(); r.sum_duplicates(); r.sort_indices(); return r


def execute_fast(case, k, rule, solver='ydct', nx=32, nz=48):
    """Same step order and clock points as e6_run.execute(); basis/solve swapped."""
    start = time.perf_counter()
    g = mesh.Grid(nx, nz, case['bottom']); a = time.perf_counter()
    b = -g.cell_volume * g.divergence(case['u_star']); bb = time.perf_counter()
    beds = sorted(set(int(v) for v in np.unique(g.bottom)))
    if rule == 'mid':
        kc = {bd: (bd + nz - 18 - 1) // 2 for bd in beds}
    else:
        G = types.SimpleNamespace(bottom=g.bottom, ids=g.ids)
        kc = placement.per_type(G, b)
    knots = {bd: [bd, kc[bd]] + list(range(nz - 18 - 1, nz)) for bd in beds}
    B = FastBasis(g, knots); c = time.perf_counter()
    Ared = B.assemble(); bred = B.restrict(b); d = time.perf_counter()
    if solver == 'ydct':
        x = rs.YDCTBlock(Ared, B.knots, g.bottom).solve(bred); it = 0
    else:
        x, it, sr, backend = solvers.solve(Ared, bred, 'jacobi', tol=1e-10, maxiter=1000)
    e = time.perf_counter()
    p0 = B.prolong(x); f = time.perf_counter()
    inv = 1. / g.A.diagonal() if k else None
    h = time.perf_counter(); p = p0.copy()
    for _ in range(k):
        p += 1.0 * inv * (b - g.A @ p)
    i = time.perf_counter()
    u = case['u_star'] + g.pressure_jump(p) / g.distance
    j = time.perf_counter()
    residual = b - g.A @ p; postdiv = g.divergence(u)
    cert = mesh.certificate(g, case['u_star'], u)
    end = time.perf_counter()
    clocks = dict(basis_ms=(c - bb) * 1e3, reduced_assembly_rhs_ms=(d - c) * 1e3, backend_ms=(e - d) * 1e3,
                  prolong_ms=(f - e) * 1e3, post_smooth_ms=(i - h) * 1e3, total_ms=(end - start) * 1e3)
    return dict(timings=clocks, kc=kc, iterations=it), dict(g=g, b=b, phi0=p0, phi=p, u_after=u, residual=residual)


def execute_e7(case, k, variant):
    engine.mesh = types.SimpleNamespace(Grid=mesh.Grid, certificate=mesh.certificate,
                                        Basis=lambda g, t: basis.DepthBasis(g, t))
    spec = dict(method=f'{variant}-k{k}', t=variant, k=k, omega=1.)
    row, art = engine.execute(case, spec)
    return dict(timings={kk: row['timings'][kk] for kk in ('basis_ms', 'reduced_assembly_rhs_ms', 'backend_ms', 'prolong_ms', 'post_smooth_ms', 'total_ms')},
                iterations=row['iterations']), art


def quality(art, us, pref, A, M):
    e = art['phi'] - pref; E = float(e @ (A @ e))
    return dict(E=E, vel=float(np.sqrt(E / np.dot(M, us * us))), div=float(np.linalg.norm(art['residual']) / np.linalg.norm(art['b'])),
                abs_res=float(np.linalg.norm(art['residual'])))


def main():
    decl, dsha = check_frozen()
    out = HERE / 'results'; out.mkdir(exist_ok=False)
    bottom = k3d.step_bottom(12); gl = mesh.Grid(32, 48, bottom, build_matrix=False); G0 = mesh.Grid(32, 48, bottom)
    cases = {}
    rng = np.random.default_rng(decl['rng_seed'])
    for seed in decl['inputs']['surface']:
        cases[f'surface-s{seed}'] = dict(bottom=bottom, u_star=iw.generate_surface(gl, seed), family='surface')
    for seed in decl['inputs']['bulk']:
        mode = int(rng.choice([5, 6, 7, 8, 9])); frac = float(rng.uniform(-.5, .5))
        cases[f'bulk-s{seed}'] = dict(bottom=bottom, u_star=iv.generate(gl, 'bulk', seed, z0_cells=frac * 96 / mode, mode=mode), family='bulk', mode=mode, z0_fraction=frac)
    for cname in decl['inputs']['e7']:
        with np.load(ROOT / f'data/inputs/{cname}.npz', allow_pickle=False) as z:
            cases[cname] = dict(bottom=z['bottom'].copy(), u_star=z['u_star'].copy(), family='design')
    # K10b: reference and quality on each case's own grid (fresh-nonaligned has its step at x=13)
    GRID = {n: mesh.Grid(32, 48, c['bottom']) for n, c in cases.items()}
    PREF = {n: splu(GRID[n].A.tocsc()).solve(-GRID[n].cell_volume * GRID[n].divergence(c['u_star'])) for n, c in cases.items()}
    pipes = dict(e7_mid=lambda c, k: execute_e7(c, k, 'deep_midpoint'), e7_top19=lambda c, k: execute_e7(c, k, 'top19'),
                 fast_mid=lambda c, k: execute_fast(c, k, 'mid'), fast_ic=lambda c, k: execute_fast(c, k, 'ic'))
    # equivalence (untimed)
    eq = {}
    for n, c in cases.items():
        r1, a1 = execute_e7(c, 8, 'deep_midpoint'); r2, a2 = execute_fast(c, 8, 'mid', solver='cg'); r3, a3 = execute_fast(c, 8, 'mid')
        eq[n] = dict(fast_cg_bitwise=bool(all(np.array_equal(a1[k], a2[k]) for k in ('phi0', 'phi', 'u_after', 'residual'))),
                     ydct_phi_rel=float(np.linalg.norm(a3['phi'] - a1['phi']) / np.linalg.norm(a1['phi'])),
                     ydct_E_rel=abs(quality(a3, c['u_star'], PREF[n], GRID[n].A, GRID[n].M)['E'] - quality(a1, c['u_star'], PREF[n], GRID[n].A, GRID[n].M)['E']) / quality(a1, c['u_star'], PREF[n], GRID[n].A, GRID[n].M)['E'])
    print('equivalence', json.dumps(eq), flush=True)
    qual = {}
    for n, c in cases.items():
        for pname, fn in pipes.items():
            for k in (0, 8):
                r, art = fn(c, k)
                qual[f'{n}|{pname}|k{k}'] = dict(**quality(art, c['u_star'], PREF[n], GRID[n].A, GRID[n].M), kc=r.get('kc'), iterations=r.get('iterations'))
    trials = []
    order0 = [(n, p, k) for n in cases for p in pipes for k in (0, 8)]
    for rnd in range(decl['rounds']):
        order = [order0[i] for i in rng.permutation(len(order0))]
        for n, p, k in order:
            r, _ = pipes[p](cases[n], k)
            trials.append(dict(round=rnd, input=n, pipeline=p, k=k, **r['timings']))
        print(f'round {rnd} done', flush=True)
    write_json(out / 'k10.json', dict(declaration_sha256=dsha, env=env_record(), equivalence=eq, quality=qual, trials=trials,
                                      cases={n: {kk: v for kk, v in c.items() if kk not in ('bottom', 'u_star')} for n, c in cases.items()}))


if __name__ == '__main__':
    main()
