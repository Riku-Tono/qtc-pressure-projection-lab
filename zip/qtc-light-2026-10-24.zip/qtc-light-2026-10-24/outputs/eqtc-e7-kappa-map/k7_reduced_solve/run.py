"""Stage K7: timing of reduced-system solvers under an equal-quality condition.

Pipeline part timed (per input, per basis): Ar assembly (P^T A P), solver setup,
solve, prolongation P x. Building P itself is excluded (identical for all
methods; reported once). Methods:
  e7_cg        : E7's reduced CG (diagonal preconditioner, rtol 1e-10, matrix copy incl.)
  ydct         : exact y-cosine / batched block-Thomas solver (lib/redsolve.YDCTBlock)
  colblock_cg  : CG + column-block (tridiagonal) Jacobi preconditioner
  amg_cg       : CG + pyamg smoothed aggregation
Scenarios: 'fresh' (assembly + setup + solve + prolong) and 'reuse' (solve +
prolong with Ar and the setup cached). Single-thread BLAS, 7 rounds, order
shuffled per round with a fixed seed, one untimed warm-up per method.
Equal-quality check: every timed output is compared with a direct-LU reduced
solution (A-norm error) and its final error energy E with the reference.
usage: python -I -B run.py
"""
import sys, json, time
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'lib'))
import common  # noqa  (sets single-thread BLAS env vars before numpy)
from common import sha, env_record
from jsonsafe import write_json
import numpy as np
from scipy.sparse.linalg import splu
from time import perf_counter
import k3d, placement, redsolve as rs
import inputs_wave as iw
import inputs_variant as iv


def check_frozen():
    side = (HERE / 'declaration.sha256').read_text().split()[0]
    if sha(HERE / 'declaration.json') != side:
        raise SystemExit('declaration changed')
    decl = json.loads((HERE / 'declaration.json').read_text(encoding='utf-8'))
    bad = [p for p, h in decl['hash_links'].items() if sha(ROOT / p) != h]
    if bad:
        raise SystemExit('hash-linked files changed: ' + ', '.join(bad))
    return decl, side


def main():
    decl, dsha = check_frozen()
    out = HERE / 'results'; out.mkdir(exist_ok=False)
    S = k3d.Solver(k3d.step_bottom(12)); g = S.g; A = S.A.tocsr()
    inputs = {}
    for case in decl['inputs']['e7']:
        with np.load(ROOT / f'data/inputs/{case}.npz', allow_pickle=False) as z:
            inputs[case] = z['u_star'].copy()
    for seed in decl['inputs']['surface']:
        inputs[f'surface-s{seed}'] = iw.generate_surface(S.gl, seed)
    for seed in decl['inputs']['bulk']:
        inputs[f'bulk-s{seed}'] = iv.generate(S.gl, 'bulk', seed)
    RHS = {k: k3d.rhs_of(S.grid, u) for k, u in inputs.items()}
    lu_full = splu(A.tocsc())
    PREF = {k: lu_full.solve(b) for k, b in RHS.items()}
    # bases: geometry midpoint and the IC per-type choice for each input
    cases = []
    for name, b in RHS.items():
        for bname in decl['bases']:
            kc = {0: 14, 12: 20} if bname == 'mid' else placement.per_type(g, b)
            cases.append((name, bname, kc))
    prepared = {}
    for name, bname, kc in cases:
        key = (kc[0], kc[12])
        if key not in prepared:
            kl, _ = k3d.knot_lists(g, kc_abs=kc)
            t = perf_counter(); P = common.build_P(g, kl); tP = perf_counter() - t
            Ar = (P.T @ A @ P).tocsr(); Ar.sum_duplicates(); Ar.sort_indices()
            prepared[key] = dict(kl=kl, P=P, Ar=Ar, P_build_ms=tP * 1e3, lu=splu(Ar.tocsc()))
    def run_method(meth, scen, name, key, cache):
        pr = prepared[key]; P, kl = pr['P'], pr['kl']; b = RHS[name]
        t0 = perf_counter()
        if scen == 'fresh':
            Ar = (P.T @ A @ P).tocsr(); Ar.sum_duplicates(); Ar.sort_indices()
        else:
            Ar = pr['Ar']
        t1 = perf_counter()
        br = np.asarray(P.T @ b).ravel()
        info = {}
        if meth == 'e7_cg':
            t2 = perf_counter(); x, info = rs.cg_jacobi(Ar, br)
        elif meth == 'ydct':
            if scen == 'fresh' or ('ydct', key) not in cache:
                cache[('ydct', key)] = rs.YDCTBlock(Ar, kl, g.bottom)
            t2 = perf_counter(); x = cache[('ydct', key)].solve(br)
        elif meth == 'colblock_cg':
            if scen == 'fresh' or ('cb', key) not in cache:
                cache[('cb', key)] = rs.ColBlock(Ar, kl)
            t2 = perf_counter(); x, info = rs.cg_pre(Ar, br, cache[('cb', key)].solve)
        elif meth == 'amg_cg':
            if scen == 'fresh' or ('amg', key) not in cache:
                cache[('amg', key)] = rs.AMG(Ar)
            t2 = perf_counter(); x, info = rs.cg_pre(Ar, br, cache[('amg', key)].solve)
        t3 = perf_counter(); p = P @ x; t4 = perf_counter()
        return p, x, dict(assembly_ms=(t1 - t0) * 1e3, setup_ms=(t2 - t1) * 1e3, solve_ms=(t3 - t2) * 1e3, prolong_ms=(t4 - t3) * 1e3,
                          total_ms=(t4 - t0) * 1e3, **info)
    methods = decl['methods']; scenarios = decl['scenarios']
    rng = np.random.default_rng(decl['shuffle_seed'])
    trials = []; quality = {}
    cache = {}
    # warm-up and quality (untimed use)
    for name, bname, kc in cases:
        key = (kc[0], kc[12]); pr = prepared[key]
        x_lu = pr['lu'].solve(np.asarray(pr['P'].T @ RHS[name]).ravel())
        e_lu = pr['P'] @ x_lu - PREF[name]; E_lu = float(e_lu @ (A @ e_lu))
        for meth in methods:
            for scen in scenarios:
                p, x, info = run_method(meth, scen, name, key, cache)
                e = p - PREF[name]; E = float(e @ (A @ e)); Ar = pr['Ar']
                d = x - x_lu
                quality[f'{name}|{bname}|{meth}|{scen}'] = dict(E=E, E_lu=E_lu, E_rel_diff=abs(E - E_lu) / E_lu,
                    x_Anorm_rel_err=float(np.sqrt(d @ (Ar @ d)) / np.sqrt(x_lu @ (Ar @ x_lu))),
                    reduced_rel_residual=float(np.linalg.norm(np.asarray(pr['P'].T @ RHS[name]).ravel() - Ar @ x) / np.linalg.norm(np.asarray(pr['P'].T @ RHS[name]).ravel())),
                    iterations=info.get('iterations'))
    print('quality done', flush=True)
    for rnd in range(decl['rounds']):
        order = [(c, m, s) for c in range(len(cases)) for m in methods for s in scenarios]
        order = [order[i] for i in rng.permutation(len(order))]
        for ci, meth, scen in order:
            name, bname, kc = cases[ci]; key = (kc[0], kc[12])
            p, x, info = run_method(meth, scen, name, key, cache)
            trials.append(dict(round=rnd, input=name, basis=bname, kc=list(key), method=meth, scenario=scen, **info))
        print(f'round {rnd} done', flush=True)
    res = dict(declaration_sha256=dsha, env=env_record(), cases=[dict(input=n, basis=b, kc=[k[0], k[12]]) for n, b, k in cases],
               P_build_ms={f'{k[0]}_{k[1]}': v['P_build_ms'] for k, v in prepared.items()}, quality=quality, trials=trials)
    write_json(out / 'k7.json', res)


if __name__ == '__main__':
    main()
