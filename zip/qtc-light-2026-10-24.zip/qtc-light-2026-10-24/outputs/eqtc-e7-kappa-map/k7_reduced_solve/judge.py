"""Summarise K7 timing under the frozen rules (same-round paired ratios).
usage: python -I -B judge.py
"""
import sys, json
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'lib'))
import numpy as np
from common import sha
from jsonsafe import write_json


def main():
    decl = json.loads((HERE / 'declaration.json').read_text(encoding='utf-8'))
    d = json.loads((HERE / 'results/k7.json').read_text(encoding='utf-8'))
    R = decl['rules']; T = d['trials']
    def get(inp, bas, meth, scen):
        return {t['round']: t for t in T if t['input'] == inp and t['basis'] == bas and t['method'] == meth and t['scenario'] == scen}
    rows = []
    for c in d['cases']:
        inp, bas = c['input'], c['basis']
        row = dict(input=inp, basis=bas, kc=c['kc'])
        for scen in ('fresh', 'reuse'):
            base = get(inp, bas, 'e7_cg', scen)
            row[f'e7_cg_{scen}_ms_median'] = float(np.median([t['total_ms'] for t in base.values()]))
            for meth in decl['methods']:
                if meth == 'e7_cg':
                    continue
                m = get(inp, bas, meth, scen)
                ratios = [m[r]['total_ms'] / base[r]['total_ms'] for r in base]
                row[f'{meth}_{scen}_ratio_median'] = float(np.median(ratios)); row[f'{meth}_{scen}_ratio_range'] = [float(min(ratios)), float(max(ratios))]
                row[f'{meth}_{scen}_ms_median'] = float(np.median([t['total_ms'] for t in m.values()]))
                for part in ('assembly_ms', 'setup_ms', 'solve_ms', 'prolong_ms'):
                    row[f'{meth}_{scen}_{part}_median'] = float(np.median([t[part] for t in m.values()]))
            for part in ('assembly_ms', 'setup_ms', 'solve_ms', 'prolong_ms'):
                row[f'e7_cg_{scen}_{part}_median'] = float(np.median([t[part] for t in base.values()]))
            its = [t.get('iterations') for t in base.values()]
            row[f'e7_cg_{scen}_iterations'] = its[0]
        rows.append(row)
    Q = d['quality']
    q_ok_ydct = all(v['reduced_rel_residual'] <= R['ydct_residual'] and v['E_rel_diff'] <= R['ydct_E'] for k, v in Q.items() if '|ydct|' in k)
    q_ok_cg = all(v['reduced_rel_residual'] <= R['cg_residual'] for k, v in Q.items() if '_cg|' in k)
    out = dict(k7_json_sha256=sha(HERE / 'results/k7.json'), rows=rows,
               verdicts=dict(T1_ydct_fresh=all(r['ydct_fresh_ratio_median'] <= R['fresh_ratio'] for r in rows),
                             T2_ydct_reuse=all(r['ydct_reuse_ratio_median'] <= R['reuse_ratio'] for r in rows),
                             T3_quality_ydct=q_ok_ydct, T3_quality_cg=q_ok_cg),
               worst_quality={m: dict(max_E_rel_diff=max(v['E_rel_diff'] for k, v in Q.items() if f'|{m}|' in k),
                                      max_reduced_residual=max(v['reduced_rel_residual'] for k, v in Q.items() if f'|{m}|' in k),
                                      max_x_err=max(v['x_Anorm_rel_err'] for k, v in Q.items() if f'|{m}|' in k)) for m in decl['methods']})
    write_json(HERE / 'results/judgement.json', out)
    for r in rows:
        print(r['input'], r['basis'], r['kc'], 'e7 fresh %.1f ms reuse %.1f ms' % (r['e7_cg_fresh_ms_median'], r['e7_cg_reuse_ms_median']),
              '| ydct fresh x%.3f reuse x%.3f' % (r['ydct_fresh_ratio_median'], r['ydct_reuse_ratio_median']),
              '| colblock fresh x%.2f amg fresh x%.2f' % (r['colblock_cg_fresh_ratio_median'], r['amg_cg_fresh_ratio_median']))
    print(json.dumps(out['verdicts'])); print(json.dumps(out['worst_quality'], indent=1))


if __name__ == '__main__':
    main()
