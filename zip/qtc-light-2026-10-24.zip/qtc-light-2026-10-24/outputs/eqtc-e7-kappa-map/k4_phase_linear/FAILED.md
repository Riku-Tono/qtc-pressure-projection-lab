# K4 実行失敗の記録

`run.py` は計算を終えた後、結果を書き出す `write_json`（lib/common.py）で numpy.bool_ を JSON 化できずに停止しました（exit=1、`run.log`）。
判定値は書き出し前で、画面にも出力されていません（結果は観測していない）。空の `results/` は削除しました。

対応：数値型を Python 型に変換する `lib/jsonsafe.py` を追加し、同じ予測・許容値のまま `k4b_phase_linear/` で宣言し直して再実行します（`common.py` はハッシュで結ばれているため変更しません）。
