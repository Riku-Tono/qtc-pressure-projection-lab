QTC E7 κ地図研究（1Dの厳密な更新式 → 3Dの W・最良節点の予測 → 配置規則・縮約解法）

まず読むもの
  κ地図研究レポート.md   本文（定義・導出・宣言判定・探索・訂正・未決着）
  引き継ぎ.md            段の状態、中断時の再開手順、次に判定する問い

位置づけ
  outputs/eqtc-e7-phase-mechanism（位相機構追試）の続きです。既存の成果物は変更していません。
  必要なソース・入力・前回結果は byte コピーし、provenance-copies.txt に元ファイルとの
  SHA-256 一致を記録しています。静的な単発の圧力投影の代理実験で、時間発展・原QTCの
  水平四分木は扱っていません。Lightward と図書館は保留です。

構成
  vendor/      E7/E5 のソースの byte コピー（mesh, basis, solvers, inputs, e6_run）
  lib/         col1d（1列の厳密な更新式）、k3d・kmap（3D 直接解と独立列予測）、
               placement（IC 配置）、placement_res（基準残差 RIC）、redsolve（縮約系の解法。y 余弦の厳密解法を含む）、
               fastp（ベクトル化した P）、wpredict（W の合成予測）、svgheat・svgplot（図）、jsonsafe、freeze
  data/        E7 の入力・参照解（inputs, references）と前回段の結果（prev/）
  k1_* … k17_* 各段：declaration.json（凍結した予測・判定規則）、declaration.sha256、run.py、
               judge.py、run.log、results/。失敗した段は FAILED.md / FAILED_NOTES.md を残しています。
               計時の段：k7（縮約系の解法）、k10/k10b（全工程）、k13（平底前処理）、k16（二段 RSE）。
  explore/     宣言なしの探索（e01〜e17）。レポートでは [探索] と書いています。

状態
  第2区切り（K1〜K17）で作業を停止しています。未実行の段はありません。詳細は 引き継ぎ.md。
  figures/     図（SVG）。make_figs.py と make_figs_design.py が保存JSONだけから再生成します。

実行環境
  Python 3.12.14 + numpy 2.3.5 + scipy 1.16.3 (+ pyamg 5.3.0)。ワークスペースの .eqtc-e4-deps を
  上位フォルダーから自動で探します（別の場所なら環境変数 EQTC_DEPS で指定）。
  キャッシュを作らないよう、すべて  python -I -B <script>  で実行します。
  各段の run.py は、宣言とハッシュで結ばれたファイルが変わっている場合と、results/ が既に
  ある場合は実行を拒否します（結果を上書きしない）。

検証
  新しいフォルダーにコピーし、そのフォルダーで:  python -I -B verify_bundle.py report.json
  （SHA256SUMS、各宣言のハッシュの結び付き、主要な数値の独立な再計算、図の再生成と byte 比較）

計時（K7, K10）
  同じ機械・単一スレッド BLAS・ラウンドごとに順序をシャッフル。値はこの実行の記述で、
  一般的な高速化の主張ではありません。y 余弦の厳密解法は、y 方向に一様な底と列種別ごとの
  節点（各列の節点数が同じ）にだけ使えます。
