"""Apply the frozen K16 rules. usage: python -I -B judge.py"""
import sys, json
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'lib'))
import numpy as np
from common import sha
from jsonsafe import write_json


def main():
    decl = json.loads((HERE / 'declaration.json').read_text(encoding='utf-8'))
    d = json.loads((HERE / 'results/k16.json').read_text(encoding='utf-8'))
    R = decl['rules']; T = d['trials']; Q = d['quality']
    rows = []
    for n, meta in d['cases'].items():
        row = dict(input=n, family=meta['family'])
        for k in (0, 8):
            sel = lambda p: {t['round']: t for t in T if t['input'] == n and t['pipeline'] == p and t['k'] == k}
            e7, fm, r2 = sel('e7_mid'), sel('fast_mid'), sel('rse2')
            row[f'k{k}_rse2_over_e7'] = float(np.median([r2[r]['total_ms'] / e7[r]['total_ms'] for r in e7]))
            row[f'k{k}_rse2_over_fastmid'] = float(np.median([r2[r]['total_ms'] / fm[r]['total_ms'] for r in e7]))
            row[f'k{k}_ms'] = {p: float(np.median([t['total_ms'] for t in sel(p).values()])) for p in ('e7_mid', 'fast_mid', 'rse2')}
            row[f'k{k}_E_rse2_over_e7'] = Q[f'{n}|rse2|k{k}']['E'] / Q[f'{n}|e7_mid|k{k}']['E']
        rows.append(row)
    v = dict(R1=all(r['k8_rse2_over_e7'] <= R['time_vs_e7'] for r in rows), R2=float(np.mean([r['k8_E_rse2_over_e7'] < 1 for r in rows])) >= R['quality_rate'],
             R3=all(r['k8_rse2_over_fastmid'] <= R['time_vs_fastmid'] for r in rows))
    out = dict(k16_json_sha256=sha(HERE / 'results/k16.json'), tables_s=d['tables_s'], rows=rows, verdicts=v)
    write_json(HERE / 'results/judgement.json', out)
    for r in rows:
        print(r['input'], 'k8: rse2/e7 time %.3f, rse2/fastmid %.3f, E rse2/e7 %.3f | ms %s' % (r['k8_rse2_over_e7'], r['k8_rse2_over_fastmid'], r['k8_E_rse2_over_e7'], {k: round(x, 1) for k, x in r['k8_ms'].items()}))
    print(json.dumps(v))


if __name__ == '__main__':
    main()
