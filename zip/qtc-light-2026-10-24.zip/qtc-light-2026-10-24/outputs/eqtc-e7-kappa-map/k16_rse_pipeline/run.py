"""Stage K16: two-stage RSE pipeline on the E7 step bed (fresh scenario, timed):
  1. top18 basis (fastp) + exact y-cosine solve  -> base residual r0
  2. RSE per-type knot choice from r0 (geometry tables precomputed once, timed separately)
  3. chosen basis (fastp) + exact y-cosine solve -> p (Jacobi k = 0 / 8 afterwards)
compared with E7's own execute() ('deep_midpoint', reduced CG) and the one-stage
fast pipeline with the midpoint (fastp + y-cosine). Same E7 step order for the
remaining steps (velocity recovery, residual, certificate) inside the clock.
usage: python -I -B run.py
"""
import sys, json, time, types
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'lib'))
import common  # noqa
from common import sha, env_record
from jsonsafe import write_json
import numpy as np
from scipy.sparse.linalg import splu
import mesh, basis
import e6_run as engine
import k3d, fastp, rse_fast, redsolve as rs
import inputs_wave as iw
import inputs_variant as iv


def check_frozen():
    side = (HERE / 'declaration.sha256').read_text().split()[0]
    if sha(HERE / 'declaration.json') != side:
        raise SystemExit('declaration changed')
    decl = json.loads((HERE / 'declaration.json').read_text(encoding='utf-8'))
    bad = [p for p, h in decl['hash_links'].items() if sha(ROOT / p) != h]
    if bad:
        raise SystemExit('hash-linked files changed: ' + ', '.join(bad))
    return decl, side


def fast_solve(g, beds, knots_of_bed, b):
    G = types.SimpleNamespace(bottom=g.bottom, ids=g.ids, n=g.n)
    P = fastp.build_P_types(G, knots_of_bed)
    Ar = (P.T @ g.A @ P).tocsr(); Ar.sum_duplicates(); Ar.sort_indices()
    kl = tuple(np.array(sorted(set(knots_of_bed[int(g.bottom[divmod(c, 32)])]))) for c in range(1024))
    x = rs.YDCTBlock(Ar, kl, g.bottom).solve(np.asarray(P.T @ b).ravel())
    return P @ x


def execute_pipeline(case, k, mode, tables, nz=48):
    start = time.perf_counter()
    g = mesh.Grid(32, nz, case['bottom'])
    b = -g.cell_volume * g.divergence(case['u_star'])
    beds = sorted(set(int(v) for v in np.unique(g.bottom)))
    top = list(range(nz - 18 - 1, nz))
    if mode == 'fast_mid':
        kc = {bd: (bd + nz - 18 - 1) // 2 for bd in beds}; t_sel = 0.0
    else:
        p18 = fast_solve(g, beds, {bd: [bd] + top for bd in beds}, b)
        r0 = b - g.A @ p18
        t1 = time.perf_counter()
        G = types.SimpleNamespace(bottom=g.bottom, ids=g.ids)
        kc, _ = rse_fast.per_type(G, r0, tables); t_sel = time.perf_counter() - t1
    p = fast_solve(g, beds, {bd: [bd, kc[bd]] + top for bd in beds}, b)
    if k:
        inv = 1. / g.A.diagonal()
        for _ in range(k):
            p += inv * (b - g.A @ p)
    u = case['u_star'] + g.pressure_jump(p) / g.distance
    residual = b - g.A @ p
    cert = mesh.certificate(g, case['u_star'], u)
    end = time.perf_counter()
    return dict(total_ms=(end - start) * 1e3, select_ms=t_sel * 1e3, kc=kc), dict(phi=p, residual=residual, b=b)


def execute_e7(case, k):
    engine.mesh = types.SimpleNamespace(Grid=mesh.Grid, certificate=mesh.certificate, Basis=lambda g, t: basis.DepthBasis(g, t))
    row, art = engine.execute(case, dict(method=f'deep_midpoint-k{k}', t='deep_midpoint', k=k, omega=1.))
    return dict(total_ms=row['timings']['total_ms']), art


def main():
    decl, dsha = check_frozen()
    out = HERE / 'results'; out.mkdir(exist_ok=False)
    bottom = k3d.step_bottom(12); gl = mesh.Grid(32, 48, bottom, build_matrix=False); G0 = mesh.Grid(32, 48, bottom)
    rng = np.random.default_rng(decl['rng_seed'])
    cases = {}
    for s in decl['inputs']['surface']:
        cases[f'surface-s{s}'] = dict(bottom=bottom, u_star=iw.generate_surface(gl, s), family='surface')
    for s in decl['inputs']['bulk']:
        mode = int(rng.choice([5, 6, 7, 8, 9])); frac = float(rng.uniform(-.5, .5))
        cases[f'bulk-s{s}'] = dict(bottom=bottom, u_star=iv.generate(gl, 'bulk', s, z0_cells=frac * 96 / mode, mode=mode), family='bulk')
    t = time.perf_counter(); tables = rse_fast.RSETables([0, 12]); t_tables = time.perf_counter() - t
    lu = splu(G0.A.tocsc()); A = G0.A
    quality = {}
    for n, c in cases.items():
        pref = lu.solve(-G0.cell_volume * G0.divergence(c['u_star']))
        for k in (0, 8):
            for p in ('e7_mid', 'fast_mid', 'rse2'):
                r, art = execute_e7(c, k) if p == 'e7_mid' else execute_pipeline(c, k, p, tables)
                e = art['phi'] - pref
                quality[f'{n}|{p}|k{k}'] = dict(E=float(e @ (A @ e)), div=float(np.linalg.norm(art['residual']) / np.linalg.norm(art['b'])), kc=r.get('kc'))
    trials = []
    order0 = [(n, p, k) for n in cases for p in ('e7_mid', 'fast_mid', 'rse2') for k in (0, 8)]
    for rnd in range(decl['rounds']):
        for n, p, k in [order0[i] for i in rng.permutation(len(order0))]:
            r, _ = execute_e7(cases[n], k) if p == 'e7_mid' else execute_pipeline(cases[n], k, p, tables)
            trials.append(dict(round=rnd, input=n, pipeline=p, k=k, total_ms=r['total_ms'], select_ms=r.get('select_ms')))
        print(f'round {rnd} done', flush=True)
    write_json(out / 'k16.json', dict(declaration_sha256=dsha, env=env_record(), tables_s=t_tables, quality=quality, trials=trials,
                                      cases={n: dict(family=c['family']) for n, c in cases.items()}))


if __name__ == '__main__':
    main()
