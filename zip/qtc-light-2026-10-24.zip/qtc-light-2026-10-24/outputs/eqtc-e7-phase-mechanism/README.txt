QTC E7 追試（入力位相・発散悪化の機構・要因分離・development・Jacobi・物理量・正規化・軽量化）

まず読むもの
  E7追試レポート.md   本文（図・数式・判定・データ参照）
  00_訂正表.md        前回までの結論の訂正・限定

位置づけ
  E7（outputs/eqtc-depth-placement-lab）と、その機構解析・節点オフセット掃引の続き。
  既存成果物は変更していない。静的な単発圧力投影の代理実験で、時間発展・原QTCの
  水平四分木・未知入力への一般化は検証していない。Lightwardと図書館は保留。

構成
  vendor/        E7/E5 ソースのbyteコピー（provenance-copies.sha256）
  data/          E7の4入力と評価用参照解（byteコピー）
  lib/           共通処理・入力生成器の変種・2Dモデル・ベクトル化基底・図の描画
  stage0/        複製元との一致検査
  stage1_phase/ ... stage9c_column1d/   各段：declaration.json（凍結した宣言）、
                 declaration.sha256、実行スクリプト、run.log、results/
  stage3_factors/ は解析コードの不具合で停止した失敗記録（FAILED.md）。3bが再実行。
  posthoc/       宣言外の事後解析
  figures/       図（SVG、保存JSONのみから make_figs_12.py で再生成）
  verify_report.py / report_claims.json   レポートの数値・判定と結果の照合
  verify_bundle.py                         配布物の検証（作業用コピーで実行）

実行環境
  E7と同じ Python 3.12 + numpy 2.3.5 + scipy 1.16.3（+ pyamg 5.3.0）。
  ワークスペースの .eqtc-e4-deps を上位フォルダーから自動で探す。別の場所なら
  環境変数 EQTC_DEPS にそのフォルダーを指定する。キャッシュを作らないよう
  すべて  python -I -B <script>  で実行する。

主な再実行
  python -I -B stage0_checks.py [<E7 lab>]          複製元との一致
  python -I -B verify_report.py                      レポートと結果の照合
  python -I -B verify_bundle.py <新しい作業フォルダー> <報告.json>
      SHA256、判定の再実行、段階1・9b・9cの再計算とbit比較、検証対象の不変性
  各段の run3d.py は、宣言と依存ファイルのハッシュが一致しない場合と、
  results/ が既にある場合は実行を拒否する（結果を上書きしない）。

計時（段階7）
  同じ機械・単一スレッドBLAS・7ラウンド順序シャッフル。値はこの実行の記述で、
  一般的な高速化の主張ではない。縮約法と細格子CGは品質が違うので比較しない。
