E7: QTC代理圧力基底の自由度追加位置を比較する実験

対象と限界
  保存E6の4入力をexact byteで再使用し、18層、深部中点1個追加、19層を
  補正0回/8回で比較します。各追加案は列ごと1個、合計1024自由度を追加。
  静的な単発圧力投影の代理実験です。原QTC/EQTCの水平四分木、自由表面の
  時間発展、新入力への一般化を検証するものではありません。
  Lightwardと図書館は保留のままです。

固定した数式
  b=-V div(u*), A=B^T diag(area/distance) B, Ar=P^T A P, br=P^T b
  zero-init diagonal-preconditioned CG: rtol1e-10, atol0, maxiter1000
  p0=P x; p(j+1)=p(j)+(b-Ap(j))/diag(A), omega=1 の同時Jacobi
  u_after=u*+pressure_jump(p)/distance
  referenceは同じ細格子CG rtol1e-13、true residual<=1e-11、評価専用。
  上面の半セルDirichlet条件と固体の側面/底面条件は既存E6から固定です。

基底
  top18: local_bottom と z29..47を節点、20480自由度、既存E6と同一。
  deep_midpoint: top18へfloor((local_bottom+29)/2)を追加、21504自由度。
  top19: local_bottom と z28..47を節点、21504自由度、従来の19層基底。
  追加位置は幾何だけで事前固定し、入力・残差・参照解で選びません。
  浅い列の規則もE6と同一です。正式4入力では全1024列で1自由度増加。
  Pnew T=P18であることを、T=P18[new nodal fine rows,:]で別途検算。
  入れ子空間なので0回補正時のAenergy誤差非増を予測します。8回後の順位を
  保証する性質はありません。同数自由度でも行列nnzやCG回数は異なります。

実装と固定
  vendor/e6_run.py、mesh.py、solvers.py、requirementsはE6からbytecopy。
  E6 execute/reference/diagnosticsを再使用し、private mesh proxyで基底factory
  だけを差し替えます。共有mesh moduleのBasisは書き換えません。
  plan.json、計算ソース、入力来歴をdeclaration.jsonへ実行前にhash固定します。
  同梱data/e6-source-snapshotは入力4本、元18層0/8回raw8本、E6の元ソースと
  metadataを保持し、元のE6フォルダが無くても再現できます。

実行
  requirements.txtに一致するPythonで:
      python reproduce.py --check-inputs
      python run.py --selfcheck
      python run.py
  公式結果は上書き禁止です。再実行は新規保存先を指定します:
      python reproduce.py --out verification-reproduced
  --check-inputsは標準Pythonだけで同梱byteの破損を検査します。
  依存インストール例: python -m pip install -r requirements.txt
  ローカル実測はbundled Pythonで、workspace .eqtc-e4-depsを使用します。
  その場所がなくても通常のrequirementsインストールで実行できます。

計時
  4入力x(基底3案x補正2種+fineCG)=28条件、各1warmup、5seed-shuffled rounds。
  正式計時は140呼出し。canonical保存用28呼出しと参照解4本は別です。
  毎回fresh: geometry metadata/fineCSR/RHS/P/RAP/RHS/solver準備・setup・CG/
  prolong/補正対角の準備/sweeps/速度復元/reference不要の残差・certificate。
  geometry_metadata_ms + fine_matrix_ms + fine_rhs_ms + basis_ms +
  reduced_assembly_rhs_ms + backend_ms + prolong_ms + smooth_setup_ms +
  post_smooth_ms + recovery_ms + check_ms = total_ms（丸めを除く）。
  補正費を見るときはsmooth_setupも含めます。入力読込、評価reference、
  reference誤差、領域診断、履歴、包含検査、hash、I/Oは計時外です。
  import/OS/hardwareがcoldという意味ではありません。継続行列再利用も未測定。
  同round fineCG比、同round深部中点/19層比と中央値を保存。5標本の範囲を
  超えて一般的な高速化を主張しません。

保存と不合格
  verification/observations.json: 28canonical結果、140timed、28warmup。
  raw/: 各条件の全3D圧力/phi0、面速度、残差、A/P/ArのCSR、b/br/x、対角、
  0..8全履歴、knots/nodal rows。reference4本を含む32本。finite failureは
  statusと追加rawへ保持し、fallbackや品質の閾値変更を行いません。
  original E5 labelは入力正規化速度誤差2%、発散比5%、net topflux1e-8。
  これは診断ラベルだけで、合格結果の選別には使いません。
  summary.jsonは5計時の中央値/範囲/同round比とcanonical品質を保持。
  timings.csv(28条件)、timing_trials.csv(140計時)を同時出力。

分布診断
  residual=b-Ap=-V div(u_after)、e^TAe=(u-u_ref)^T M (u-u_ref)。
  layer_residual_l2は各zの残差L2、error_energy_by_axisは面方向別M重み誤差。
  depth_face_error_energyは内側面の誤差を両側流体セルへ半分ずつ、上面は
  片側流体セルへ全量配分した深度集計です。error_energy_regionsも同じ配分で
  local_bottom、local_bottom<z<29、z29、z>29を排他的に区分します。
  この配分は解法や誤差ノルムを変更しません。rawは全分布を保持します。

検証
  selfcheck.jsonは小さな4x4x10開発格子のみ。dense解/1step Jacobi/入れ子/
  Galerkin energy非増/残差と発散/速度と圧力エネルギー恒等式を確認します。
  公式入力のgeometry_checksはDOF、節点identity、partition、包含を確認。
  previous_E6_crosscheckは保存E6top18 k0/k8の圧力・速度・残差・Pを照合。
  独立audit、破損control、browser確認、展開copy検証は別記録へ保存します。
  中断/失敗した出力folderも削除せず、新規folderを使って再実行します。

保存結果の表示
  index.htmlは保存JSONを埋め込んだ単独HTMLです。入力4件、補正0/8、残差/圧力差/
  局所誤差エネルギーを切り替えられます。基底3案は同じ色幅で比較し、全深さの
  誤差エネルギー分布と行列非零数/CG回数/区間時間も表示します。
  開いただけでは求解・再計時しません。全3Dデータはraw NPZに残っています。
  figures/にはReportLabで作った8枚のベクトルSVGを保存しています。

レポートだけを再構築
  report-requirements.txtを満たすPythonで python make_viewer.py を実行します。
  保存observations/summary/checksから表示・文章・図を再生成するだけです。
  求解・計時は再実行しません。原結果のmanifestを確認してから行ってください。
  表の区間時間はそれぞれ5回の中央値です。区間ごとの中央値の和を総中央値と
  解釈しません。基底構築の差には今回のPython実装の費用も含みます。

独立検算と配布コピー
  python audit.py --output <別フォルダ/checks.json>
  python handoff.py verify
  auditはproductionをimportせず、face graph・節点・包含・行列・Jacobi・誤差・
  全保存状態を独立再構築します。verification/negative-controlsには検出用の
  意図的な破損fixture8例を同梱しています。これらは正式の不合格rawと別です。
  auditによる計時の加算検証は、OSの実行状態や時間の因果効果を保証しません。
  展開コピーは --root <展開先> --output <外部check.json> で不変のまま検算可能。
  browser-qa.mjsは同PCのbundled Playwright/Chromeを使い、24選択状態・3分布・
  desktop/mobile・SVGを確認します。node browser-qa.mjs <外部browser-check.json>
  ならスクリーンショットも外部へ保存し、展開物を変更しません。

前成果物の保護
  handoff.py protect/check-previousにより旧E6の122ファイル(SHAmanifest含む)と
  旧残差解析の22ファイルを開始前/終了後に照合します。Lightwardと図書館に対する
  変更・再計測は行っていません。
