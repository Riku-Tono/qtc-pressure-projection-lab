EQTC着想・圧力投影 E0
=====================

2026-10-23。ユーザーの依頼に基づき「EQTCの使い道提案」のChatGPTと
Claude bridgeに協議し、一回の圧力投影を比較する段階を実装した。
入口は index.html。保存済み結果を表示し、開いても新しい計測は始めない。
結果の読み取りは 結果.txt、再検証の記録は checks.json を参照。

これはEQTCの原実装・完全再現ではない。共通のMAC細格子に対して
鉛直一次の縮約圧力空間を使い、固定層と可変層の機構を調べる実験。
水面追跡、移流、雨滴の質量注入、飛沫、時間発展はまだ実装していない。
表面の図は法線方向速度であり、動く水面の高さ・見た目ではない。

実行環境
--------
Windows / Intel Core i7-1165G7。NumPyの数値計算はBLAS/OMPを1スレッドに固定。
Python: C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe
Node: C:\Program Files\nodejs\node.exe
追加の依存インストールは不要。NumPy 2.3.5 / Python 3.12.14。

このフォルダーをカレントディレクトリにしたPowerShell:

  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' test_solver.py
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -u run.py --refinement
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' finalize.py
  node build-report.mjs
  node serve.mjs

保存場の鉛直診断（新しい投影や計時は実行しない）:
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' profiles.py
保存基底の包含検査（新しい投影や計時は実行しない）:
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' containment.py

ローカル閲覧: http://127.0.0.1:8769/ 。index.htmlの直接表示も可能。
再計測は今回生成したverification/内の同名データを置き換えるので、
以前の結果を残したい場合はこの実験フォルダーをコピーして実行する。

保存物
------
plan.json: 本計測前に固定したケース、閾値、反復、費用の数え方。
solver.py: fine FV operator、PCG、鉛直一次基底、AOL型qと層生成。
run.py: 同一入力を使う品質/時間計測、CSV、NPZ。
verification/observations.json: 全ケース/反復/指標/ソースとデータのSHA-256。
verification/measurements.csv: 設定ごとの数値。
verification/timings.csv: ウォームアップを除いた各反復の処理時間。
raw/: レポートと監査で使う公開NPZ（verification/raw/と同一バイト列）。
checks.json: production solverをimportしない独立再計算の監査。
verification/vertical-profiles.txt/.json: 保存場の深さ別の発散・速度誤差とハッシュ。
verification/containment.txt/.json: 圧力空間の包含と速度誤差下限の検算。
verification/browser-checks.json: 実ブラウザー操作・応答表示と画面/ソースのハッシュ。
test_solver.py: 離散固有モード、密行列参照、静水、基底、負例等の数学検査。
results.js: レポート用に生成した静的なデータ。HTMLには実験コードを含めない。
collaboration-chatgpt.json / collaboration.txt: 協議、採用事項、保留事項。
sources/: 著者版PDF、抽出テキスト、確認用の方法ページ画像。
smoke/: 本計測前の小さな動作確認。最終的な比較には混ぜない。

原論文との差分
--------------
1. 水平適応: 全列を最細quadtree葉に固定し、水平粗化を行わない。
   表層の広範囲に詳細があり、水平方向に粗くしにくい状況を切り出した。
2. 圧力離散化: 原論文のminimal-face/virtual-faceの直接構成ではなく、
   共通細格子Ah上のP^T Ah Pを使う。全背景面の勾配を含める違いがある。
3. tall部分: 下端/上端の二つの細格子圧力サンプルを残して鉛直線形補間。
   圧力サンプルの場所も原論文の完全な幾何構成を再現したものではない。
4. 層判定: AOLの速度変換誤差q、EQTCのI=sum(q)/Nyとclamp式を採用。
   Uref=1 m/sによる無次元化、alpha=100/400/1600は本実験で明示的に選んだ。
   論文にEQTCの数値alphaは見つからず、AOLの0.5をそのまま移植しなかった。
5. 平面水面からの可変半径Manhattan膨張、9x9平均を5回、元の層より
   薄くしない制約を使う。境界は端値拡張、最後だけceilする実装選択がある。
6. 埋め込み固体、複雑な自由表面、連成、時間発展は対象外。

数値と判定
----------
辺長h=1/32の立方セル、水平32x32、鉛直の計算領域Ny=64。
水深16/32/48セル（H/L=0.5/1/1.5）。水面p=0、壁/底は不透過。
密度1、dt=.01、g=9.81。求めるphi=dt*p/rhoは圧力インパルス。
入力は静水・表層運動量擾乱・深部非線形鉛直変化の3種類。
擾乱のseedは0/1、静水はseed0。雨の形をした速度インパルスであり、
雨粒そのものや水量を増やす計算ではない。

fine、固定4/6/8層、可変alpha100/400/1600を比較。
同じu*、境界、PCG許容残差1e-10を使う。同自由度の一様粗格子/等方集約
対照は実施していないので、tall集約の一般的優位性は主張しない。
warmup1回後に3回反復し、
各ラウンドの方法順は固定seedでシャッフルする。参照解/指標/保存I/Oは
計時の外。共通細格子構築、層判定、基底、縮約組立、PCG、復元は計時内。
細格子を保持するため、自由度削減をメモリ削減とは呼ばない。
operator_storage_bytesは保存配列だけで、組立中の一時配列/peak RSSを含まない。

速度誤差: ||u-u_ref||_{area*distance}/||u*||_{area*distance}。
発散RMS: 細格子の体積重み付きRMS（本格子は等体積）。
div_relative: 投影後発散RMS / 投影前発散RMS。
surface_error: 表面法線速度の差のL2 / 入力表面速度のL2。
wall_force_error: 4側壁の圧力インパルス積分の合力ベクトル誤差。
動的成分の分母から静水圧を除く値もwall_force_dynamic_errorに保存。

事前の精度ゲート: 速度誤差<=2%、div_relative<=5%、
正味表面流束/入力の絶対表面流束<=1e-8。
閾値は本E0の工学的な選択であり、原論文が保証した誤差ではない。
縮約残差が小さくても細格子発散は残りうるので、両方を別に報告する。
表面の正味流束がゼロでも、局所発散ゼロや時間発展後の体積保存を意味しない。
側壁/底の法線速度は自由度から省略し、厳密に0に固定している。
自由表面は法線速度を許すので、その絶対流束を壁の漏れとは解釈しない。

解像度確認は64x64x64の水、Ny128、seed0の表層/深部のみ。
固定8/16層、可変alpha800で物理幅の目安をそろえる。品質確認1回であり、
この追加ケースの単回時間から速度向上を主張しない。

一次資料
--------
EQTC著者ページ: https://graphics.c.u-tokyo.ac.jp/en/research/beyond-horizontal-refinement/
EQTC: https://graphics.c.u-tokyo.ac.jp/archives/pg2026narita.pdf
QTC + Hindsight: https://graphics.c.u-tokyo.ac.jp/en/research/quadtree-tall-cells/
QTC: https://graphics.c.u-tokyo.ac.jp/archives/sg2025narita.pdf
AOL: https://graphics.c.u-tokyo.ac.jp/archives/eg2026narita.pdf
