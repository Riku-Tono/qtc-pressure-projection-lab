QTC E5 — direct assembly / deliberate breakage lab
2026-10-23

Saved scope
One static pressure projection on a MAC stepped-bed domain. This is a pressure
Galerkin surrogate inspired by EQTC, not the original paper implementation and
not a water-surface/time-evolution simulation.

Open index.html directly, or serve the parent outputs folder:
  python -m http.server 8778 --bind 127.0.0.1 --directory ..
  http://127.0.0.1:8778/eqtc-direct-break-lab/
The viewer embeds immutable summary and field data. Opening it runs no solver.

Files
run.py, direct.py, mesh.py: production numerical experiment.
vendor/: actual copies of E4 geometry/inputs/solvers, not imports from another lab.
mesh.py differs from vendor geometry only by optional fine matrix construction
and a separate fine-matrix timer. Original E4 files were never modified.
data/: exact snapshots of original E4 observations and one accepted development
input. No old lab files are required to reproduce or audit these results.
plan.json: declared experiment, cases, tolerances, exclusions and limitations.
verification/declaration.json: source hashes before fresh input generation.
verification/inputs-seal.json: input hashes, followed by measurements.
verification/observations.json: immutable raw numerical/timing observations.
verification/raw/: all 24 forced candidate outputs,4 fine outputs,4 references.
verification/inputs/: saved known1 + new3 actual inputs.
verification/checks.json: independent audit output (no production imports).
verification/summary.json, fields.json, timings.csv: portable report data.
結果.txt: findings, exact metrics and caveats in Japanese.
SHA256SUMS.txt: checksums of all deliverable files except this manifest.
aborted-reference-setup/: first startup preserved. Reference check failed before
any reduced solve. The revised reference setup and fresh seed are documented.

Numerical reproduction
Python3.12; NumPy2.3.5, SciPy1.16.3, PyAMG5.3.0. Install requirements.txt in your
own Python environment, or use the existing bundled runtime/dependencies:
  $env:PYTHONPATH='C:\Users\yauki\Documents\ChatGPT\ChatGPT-野望実験\.eqtc-e4-deps'
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' audit.py
  & 'C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' build_report.py
Run these from this lab folder. The PYTHONPATH option also works for an extracted
copy in another directory. The source files and saved inputs remain local to it.

run.py refuses to overwrite an existing declaration. To repeat the fixed-input
experiment, copy the entire lab to a NEW directory and rename its verification
folder to verification-original, then run:
  python -u run.py
  python audit.py
  python build_report.py
This repeats the specified inputs; it does not make them unused research inputs.
Changing the plan requires another experiment and freeze, not retuning this run.

Interpretation
18/9/0 means number of fine top layers per column, not half the DOF. Local shallow
columns retain the old full-fine fallback knot rule. Candidate selection and fine
fallback are deliberately absent: failed precision gates remain saved raw outputs.
Both assembly methods use identical pressure spaces, zero initial states, same
Jacobi-CG target, same certificate timing. Matrix/operator/RHS equivalence is
checked independently; fine residual and approximation error remain separate.
The policy's predictor and fallback expense are NOT included in this forced test,
so it does not demonstrate an E4 total-policy runtime improvement. Old E4 costs
are a conditional RAP-free reference, not a direct-implementation lower bound.
Fresh runs separately time fineCSR and assembly; free-build numbers are optimistic
counterfactuals, not runnable speed or a causal savings estimate.
Cold means fresh numerical preparation per invocation. warm continuous reuse,
process startup/import, OS/hardware-cache cold, and moving-water quality are not
measured. Five ranges are not confidence intervals; three fresh probes do not
establish generalization or an exact monotone breakage boundary.

Additional interpretation
The nonaligned-bed probe does not run E4's coarse predictor. It tests the fixed
pressure space and assembly methods on a shifted bed, not predictor support for
nonalignment. Divergence115.9% means one projection left more divergence than
the input under this norm; it does not demonstrate time-evolution instability.
The restored fine residual is saved separately in metrics.fine_residual_relative.
All solid faces are omitted by the imposed impermeable geometry, so reported
solid flux zero is structural, not an independent boundary-accuracy result.
