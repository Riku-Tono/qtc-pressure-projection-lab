E6: QTCの縮約後に少数回の細格子Jacobi補正を加える追試

対象
  E5に保存された4入力をバイト単位でコピーして使います。新規データや未知の
  held-out検証ではありません。32x32x48の静的圧力投影の代理実験であり、原QTC/
  EQTCの水平四分木・自由表面の時間発展は実装していません。
  Lightwardと図書館はこの実験に含めません。

事前に固定した実験
  plan.jsonを公式実測の前に固定し、run.py/vendorのSHA-256と一緒にdeclaration.json
  へ保存します。vendor/mesh.pyとsolvers.pyはE5から改変せずコピーしました。
  t=9,18の既存基底P、RAP構築、zero-init diagonal-preconditioned CG rtol1e-10を
  保持し、p0=Pxへ以下の同時Jacobi更新を0,1,3,8回だけ加えます。
      b=-V div(u*), A=B^T diag(area/distance) B
      p_(j+1)=p_j + (b-Ap_j)/diag(A)       omega=1
      u_after=u*+pressure_jump(p)/distance
  同じAの同じ境界行・対角を使い、各sweepでは更新前のpから全成分を同時に計算。
  zero-k0/1/3/8はp0=0からの対照、fine-cgは通常の細格子求解対照です。
  高精度の評価専用referenceはfineCG rtol1e-13、true residual<=1e-11です。

原典との関係
  Ando, Thuerey, Wojtan (2015), A Dimension-reduced Pressure Solver for Liquid
  Simulationsの細格子補正が動機です。著者のsurface-aware basisを再現した実験
  ではなく、3回の補正による論文の精度をこの代理基底へ持ち込みません。
  omega=1は本実験で明示して固定した通常Jacobiの選択です。8回後の残りだけから
  低周波/高周波、または近似空間の不足を排他的に断定しません。

実行 (bundled Python、またはrequirements.txtを満たすPython)
  python run.py --selfcheck
  python run.py
  公式結果の上書きは禁止。別の再実行は python run.py --out verification-rerun
  として新規フォルダを指定してください。失敗・中断された実行も削除しません。

実測の定義
  各method呼び出しでgrid/fineCSR/RHS/basis/RAP/CG準備・求解/prolong/補正の対角
  準備/sweeps/速度復元/reference不要な有限性・残差・divergence・certificateを
  再計算します。1回のwarmupを捨て、seed固定のランダム順で5paired rounds。
  geometry_metadata_ms + fine_matrix_ms + fine_rhs_ms + basis_ms +
  reduced_assembly_rhs_ms + backend_ms + prolong_ms + smooth_setup_ms +
  post_smooth_ms + recovery_ms + check_ms = total_ms (浮動小数点の丸めを除く)
  post_smooth_msはsweepsとpコピーのみ。補正の追加費はsmooth_setupも含めて読むこと。
  total_msには細格子残差の評価とcertificateの確認費も含みます。
  入力読込、reference、referenceを用いた誤差評価、履歴/領域診断、ハッシュ、I/Oは
  含みません。process/import/OS/hardwareがcoldという意味ではありません。
  両方式に対称な継続的行列再利用やフレーム間のwarm solveは測っていません。

保存形式 (eqtc-postsmooth-v1)
  verification/inputs/*.npz: E5入力のexact copy。inputs-provenance.jsonに旧sealの
    SHAとcopy元/先のSHA、vendorのSHA照合結果を保存。
  declaration.json: 開始前source hash、環境、計画、入力来歴。
  observations.json: methods, cases[{case_id,reference,rows}], trials。
    rowsは各入力13methodのcanonical結果。trialsは同じrow構造にround/order/
    velocity_hash/saved_solution_relativeを追加。全結果を保存します。
  raw/<case>-<method>.npz:
    method,t(-1=null),k,omega、phi0,phi,u_after,residual,b,x,br,bottom,u_star,diag,
    cell_indices、fine CSR A_data/A_indices/A_indptr/A_shape。
    縮約methodはP_*とAr_*も保存。phi_trajectoryはk+1段階のpをposthocで再計算。
    fine-cg/zeroにはP/Arはありません。x,brはzero対照では空配列です。
    referenceはphi,u_after,residual,bottom,u_starを保存。
    正式timing中の有限な結果はcanonicalとの再現誤差とhashを保存し、異常結果は
    各trialのrawも別保存します。canonicalの品質不合格もすべて残します。
  summary.json: viewer用のflattened rows。timingは5回の中央値/範囲、fine中央値、
    中央値比、同round fineとのpaired_ratiosとその中央値、各phase中央値。
  結果.txt: 全52条件の品質指標と実測時間の一覧。

指標の読み方
  velocity_error: M=face_area*distanceで重み付けしたfine referenceとの差を入力u*で
    正規化。div_relativeは入力divergenceで正規化。pressure_energy_error_relative
    はsqrt(e^TAe / pref^TApref)。前者2%/div5%/net top flux1e-8の元E5品質ラベルは
    選別/fallbackに使用しません。Jacobiは残差やnet fluxを単調に減らす保証なし。
  residual=b-Ap=-V div(u_after)。圧力errorのAenergyは速度errorのMenergyと一致。
  galerkin_residual_relative=||P^T r||/||P^T b||はk0だけ直交性を期待します。
  error_rayleigh_D=e^TAe/e^TDe、D=diag(A)。Jacobiが減衰させるスペクトルとの関連を
    見る補助診断です。単一平均量から誤差を低/高周波へ断定しません。eD²が
    1e-20*prefD²以下ならroundoff支配を避けnullにします。
  regionsはtop9/top18/deep_below18のdivRMSと入力比。historyには各sweepの残差比、
    error energy、Rayleighを保存。局所分布はrawから独立して作れます。

検証
  selfcheck.jsonは小さな開発格子だけでdense1stepと更新式、residual/divergenceの
  一致を確認した結果。公式入力の結果とは別です。
  独立audit.pyとviewer/plotの検証結果は別ファイルで残します。
  速さ・品質の双方が確認できた範囲だけを報告し、壊れた結果や負けた時間も残します。

単独フォルダからの再現
  data/e5-source-snapshot/にE5のmesh.py、vendor/solvers.py、inputs-seal.json、4入力を
  バイト単位で同梱しました。requirements.txtを満たすPythonならE5の元フォルダが
  無くても、次の入口で再計算できます。
      python reproduce.py --check-inputs
      python reproduce.py --out verification-reproduced
  reproduce.pyは固定済みrun.pyをimportし、E5入力参照先だけ同梱snapshotへ向けます。
  計算法・閾値・計時・順序は変更しません。再現入口のSHAと実際のローカル入力元を
  reproduction-entry.jsonに保存。run由来provenanceのsource_relativeは原E5の論理的
  来歴名、source絶対パスは実際に読み込んだsnapshotの場所です。
  --check-inputsは標準Pythonだけで7ファイルとseal/vendor/公式入力の一致を確認し、
  verification/reproduction-input-check.jsonを保存します。元の正式runは上書きせず、
  新規ディレクトリだけを再現先に使います。

表計算用ファイル
  python export_timing_csv.py で保存JSONからverification/timings.csv(52条件)と
  timing_trials.csv(260計時)を生成します。追加の数値求解や再計時は行いません。
  CSVのtiming値はJSONと同じミリ秒。CSVを作ったことによる新しい速度証拠はありません。

保存結果を見る
  index.htmlを直接開くと、残差/圧力差の中央断面、全深さの残差RMS、誤差・時間の
  曲線、52条件の数値を選択して表示できます。ブラウザから求解は実行しません。
  figures/にはReportLabで作った8枚のベクトルSVGがあります。表示用JSONの全深さ
  集計は全流体セルを使い、断面はy=16と明記しています。色幅は各入力・初期値の
  0/1/3/8回で共通です。原データの全3D分布はraw NPZに残っています。

レポートを再構築する場合だけ
  report-requirements.txtを満たすPythonで python make_viewer.py を実行します。
  これは保存済みobservations/summary/checksから作図・文章化するだけで、求解と
  計時を再実行しません。元ファイルのハッシュを確認してから行ってください。

保存結果の検算
  python audit.py --output <別の保存先/checks.json>
  python handoff.py verify
  auditはproductionをimportせず、面グラフ・基底・更新式・誤差・計時整合を再構築。
  arithmetic監査は実時間の正確さやハードウェア状態を保証するものではありません。
  verification/negative-controlsには検算が拒否する破損例を意図的に同梱しています。
  これらは正式raw結果ではありません。フォルダ別に保持しています。

ブラウザ確認
  browser-qa.mjsは同PCのbundled Playwright/Chromeを使い、48選択状態、残差と圧力差、
  desktop/mobile、SVGを確認します。別PCでは同ファイルの依存パスを合わせます。
  node browser-qa.mjs <別の保存先/browser-checks.json> とすると抽出物を変更せずに
  検証できます。既定出力先はverification/です。

前成果物
  previous-lab-before.jsonとprevious-lab-check.jsonで元E5の70ファイルの不変を照合。
  Lightward・図書館に対する変更や再実測は行っていません。
