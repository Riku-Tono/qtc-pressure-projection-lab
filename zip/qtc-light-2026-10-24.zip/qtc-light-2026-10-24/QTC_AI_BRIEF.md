# QTC AI向け引き継ぎ資料（一体化Markdown）

2026-10-24の保存状態を読むための資料です。計算再現用の完全版とは区別してください。
以下の原文には完全版用のコマンド・ファイルパス・次回候補があります。このファイル単体に生データや実行環境は含まれません。
研究はK7・K10b・K13・K16の4測定と結果保存を終えて停止しています。

完全版ZIPのSHA-256：`63c148becfcf0c52dea4c43ea992487c65ec22b42f916406fbeba164da5306a4`

完全版の配布検証：5,315ファイル照合、11検査PASS、展開ツリー不変。
軽量版の目的：研究の読解、結果のレビュー、次回の相談・引き継ぎ。


---

## 全体README（完全版原文）

出典：`QTC全体README.md`（リンクだけ一体化資料の位置に合わせて補正）

# QTC / EQTC 圧力投影研究 — 全体案内と再現手順

2026-10-24、Claudeによる最新のκ地図研究（K1〜K17）と4種類の速度測定・判定を含む保存版です。

この研究で扱っているのは、**共通の細格子上で、圧力を鉛直の区分線形基底へGalerkin縮約する、静的な単発圧力投影の代理実験**です。原QTC/EQTCの水平四分木、minimal/virtual-face離散化、移流、水面追跡、飛沫、時間発展を一式実装したものではありません。新規性の判定も行っていません。

目的は「計算現象の理解7割、軽量化3割」。自由度を減らしたことと、必要な精度を保って総計算時間を短くしたことを区別します。失敗、精度未達、予測の不合格、探索的な発見も保存しています。

## まず読むもの

1. **最新の成果・限界**：[最新検証のまとめ](docs/QTC-最新検証.md)
2. **導出と実験の本文**：[κ地図研究レポート](outputs/eqtc-e7-kappa-map/κ地図研究レポート.md)（§00が最新のまとめ、§11が速度測定）
3. **研究を再開する場合**：[最新の引き継ぎ](outputs/eqtc-e7-kappa-map/引き継ぎ.md)
4. **保存された場を見比べる**：E7比較ビューアー（完全版：`outputs/eqtc-depth-placement-lab/index.html`）、E6残差診断（完全版：`outputs/eqtc-residual-analysis/index.html`）、E4比較（完全版：`outputs/eqtc-stepped-bed-lab/index.html`）

HTMLは保存結果の表示です。開くだけで求解や計時を再実行することはありません。

## 現時点の到達点

- 1列・追加節点1個の更新式を厳密に導き、直接求解で検算しました。圧力の誤差エネルギーが減っても、残差の二乗・発散が増える条件を分離できました。
- 3Dで独立列近似がよく合っていた理由には、水平の遮蔽と段差近傍のスピルが打ち消し合う効果があります。両方を含めるW予測を未使用条件で検証しました。スピル係数は現在も経験値です。
- 入力右辺だけを使う配置（IC）に加え、基準残差から配置を選ぶRSEを検証しました。一般の台地・二方向の棚でも改善しますが、探索した最良側の配置と常に一致するわけではありません。
- y方向に一様な底などの条件では縮約系を厳密に分解して速く解けます。一般の底への前処理も試しました。**E4での精度付き総費用は高速化未達のまま**で、後の限定された縮約系・E7パイプラインの改善とは、比較対象と計時範囲が異なります。

### Claudeの最新4測定

比は「候補時間 ÷ 比較対象時間」で、小さいほど速い値です。下表の中央値だけで合否を決めず、事前固定した各入力の規則で判定しています。

| 測定 | 比較と主な観測 | 事前判定 |
|---|---|---|
| K7：縮約系 | y余弦解法／従来縮約CG。新規準備ありの比の中央値0.421、再利用0.035 | 新規準備のT1は最大0.506で不合格。再利用T2・品質T3は合格 |
| K10b：全工程 | 高速な中点配置パイプライン／E7基準。補正8回の比の中央値0.480 | 品質Q1〜Q3合格、速度T1・選択費用T2は不合格。元K10の格子不一致も保存 |
| K13：一般の底 | 平底の代用行列による前処理／縮約CG。新規準備の比の中央値0.649、再利用0.374 | 速度T1・T4は不合格。反復数T2・品質T3は合格 |
| K16：二段RSE | 基準求解→RSE選択→最終求解／E7中点基準。補正8回の時間比の中央値0.711、誤差E比0.581 | R1〜R3はすべて合格。幾何表の構築約3.5秒は計時外 |

これらは同じ機械・今回の入力集合・単一スレッドBLASでの観測です。K7の再利用比を全工程の速度比とは扱いません。細格子の最速法や原EQTC全体への優位性、長時間の体積保存は主張しません。詳しい比較対象、範囲、最大値と例外は[最新検証](docs/QTC-最新検証.md)を参照してください。

## 実験の流れ

| 段階 | 問いと結果 | 一次資料 |
|---|---|---|
| E0：入口 | Galerkin代理の数学・境界・独立検算。静水21/21合格、擾乱の縮約72設定は精度未達 | [結果](outputs/eqtc-fluid-lab/結果.txt)、[README](outputs/eqtc-fluid-lab/README.txt) |
| E1：層厚校正 | 参照を使うオフライン校正。表層では縮約が残る一方、深部は全基底へ回復する例がある | [結果](outputs/eqtc-thickness-lab/結果.txt) |
| E2：参照不要の自動選択 | 未使用24件の精度は合格。縮約14・fine復帰10だが、選択を含む全費用は短縮せず | [結果](outputs/eqtc-auto-layer-lab/結果.txt) |
| E3：最初の候補を予測 | 主方式は細格子CG比0.938で宣言合格。ただし矩形のfine-DCT直接法がさらに速い | [結果](outputs/eqtc-predict-layer-lab/結果.txt) |
| E4：段差・台地・二方向棚 | 42入力×5方式の最終精度合格。主24入力の総時間は最速の試験済み細格子法比1.121で高速化未達 | [結果](outputs/eqtc-stepped-bed-lab/結果.txt)、[監査](outputs/eqtc-stepped-bed-lab/verification/checks.json) |
| E5：縮約行列の直接構築 | 同じ基底でRAPと直接構築の同等性を検証。今回の直接COO実装はRAPより遅い | [結果](outputs/eqtc-direct-break-lab/結果.txt) |
| E6：細格子Jacobi補正 | 52保存解・260計時。0回で精度未達の例が、最大8回で全品質合格へ転じた例は0 | [結果](outputs/eqtc-postsmooth-lab/結果.txt) |
| E6残差診断 | 保存場の空間・スペクトル後処理。深部の表せない成分を可視化し、配置の問いへ進んだ | [診断](outputs/eqtc-residual-analysis/診断と次の実験.txt) |
| E7：深部の節点配置 | 同じ自由度の19層より深部中点追加が全8比較で低い誤差E。ただし総時間短縮は未達、深部精度も基準未達 | [最終報告](outputs/eqtc-depth-placement-final-report.txt)、比較（完全版：`outputs/eqtc-depth-placement-lab/index.html`） |
| E7機構解析 | 誤差E、残差、発散、Jacobi、物理量の定義と恒等式を調べた | [レポート](outputs/eqtc-e7-mechanism-analysis/E7機構解析レポート.md) |
| 節点オフセット掃引 | 置き場所によってEと発散が異なる変化をする条件を探索した | [レポート](outputs/eqtc-e7-knot-offset-sweep/節点オフセット掃引レポート.md) |
| 位相機構追試 | 事前予測、位相・列種別・相互作用、独立検算を進めた。初期解釈には訂正がある | [本文](outputs/eqtc-e7-phase-mechanism/E7追試レポート.md)、[訂正表](outputs/eqtc-e7-phase-mechanism/00_訂正表.md) |
| κ地図研究：最新 | 1D厳密式→未知条件の予測→3D機構→RSE配置と解法。K1〜K17で一区切り | [本文](outputs/eqtc-e7-kappa-map/κ地図研究レポート.md)、[引き継ぎ](outputs/eqtc-e7-kappa-map/引き継ぎ.md) |

古いレポートの「次の実験は未実施」は、その保存時点の記述です。原資料を改変せず、進行と訂正をこの案内で接続しています。参考ログの役割は[研究経緯](docs/QTC-研究経緯.md)に記載しています。

## 再現用ZIPの内容

配布ファイル名：`qtc-research-2026-10-24.zip`。開発ワークスペースでは `outputs/qtc-research-delivery-2026-10-24/` にZIP、SHA-256、検証記録を置きます。

```text
qtc-research-2026-10-24/
  README.md
  docs/                         最新結果と研究経緯
  requirements-qtc.txt          数値依存の固定版
  .eqtc-e4-deps/                Windows x64 / CPython 3.12用の数値依存
  scripts/qtc_repro/            共通の検証・実行・再梱包コマンド
  bundle-manifest.json          全収録ファイルのサイズとSHA-256
  outputs/
    eqtc-fluid-lab/             E0
    ...                        E1〜E7、診断、機構解析、掃引
    eqtc-e7-phase-mechanism/    位相機構追試
    eqtc-e7-kappa-map/          最新研究、失敗履歴、再開情報
```

入力、参照解、生のNPZ、宣言、ソース、探索・不合格・中断記録、レポート、既存の検証記録を収録します。旧ZIPとその展開・stagingの重複、別プロジェクト、実行キャッシュ、会話ログ全体は収録しません。E0〜E4などの由来照合が兄弟フォルダーを参照するため、`outputs/`の構造を保ってください。

### 1. ZIPを確認して展開する

Windows PowerShellで、ZIPと`.sha256`を同じ場所に保存して実行します。

```powershell
$zipPath = '.\qtc-research-2026-10-24.zip'
$expected = ((Get-Content -LiteralPath ($zipPath + '.sha256')).Split(' ')[0]).ToLowerInvariant()
$actual = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected) { throw 'ZIP SHA-256 mismatch' }
Expand-Archive -LiteralPath $zipPath -DestinationPath '.\qtc-extracted'
Set-Location '.\qtc-extracted\qtc-research-2026-10-24'
```

新しい展開先を使ってください。ZIPにはPythonインタープリターは含めていません。

### 2. 保存結果を検算する（推奨の入口）

確認した環境は **Windows x64 / CPython 3.12.14**、NumPy 2.3.5、SciPy 1.16.3、PyAMG 5.3.0です。数値パッケージを同梱しているため、この環境では追加インストールやネット接続は不要です。

```powershell
py -3.12 -I -B -S scripts/qtc_repro/verify_bundle.py --out ..\qtc-check
```

`py`ランチャーがなければ、`py -3.12`をPython 3.12実行ファイルへのパスに置き換えます。`-I -B -S`でユーザー環境・site-packages・キャッシュ生成から切り離し、展開した依存を明示的に読みます。各検証JSONに実際のパッケージの読込元を記録します。

このコマンドは、全ファイルのSHA照合、E0〜E7の保存配列の監査、残差診断manifest照合、位相追試の選択した段の再計算、最新κ研究の宣言・主要数値・図の再生成を順番に実行します。結果は別フォルダーの `checks.json` と各段のJSON・ログに保存します。元の展開物が変わっていないことも再照合します。

共通入口は元の研究ソースを変更せず呼び出します。位相追試では、移動先で変わる依存フォルダーなどの環境情報`env`を数値JSONの比較から分離し、旧・新の環境を別項目に記録します。NumPy/SciPy版とスレッド設定の一致、すべての対象数値とraw配列の一致は別に検査します。子プロセスにも同梱依存の起動補助を適用します。

これは**全実験・全計時の最初からの再実行ではありません**。機構解析・オフセット掃引の全条件の再計算、当時のブラウザーQAの再実行も含みません。各検査の範囲は検証JSONに残します。全体検証は数分以上かかる場合があります。

```powershell
# 数値計算をせず収録ファイルだけ照合
py -3.12 -I -B -S scripts/qtc_repro/verify_bundle.py --checks hashes --out ..\qtc-hash-check

# 最新研究だけを再検算（全ファイル照合も実行）
py -3.12 -I -B -S scripts/qtc_repro/verify_bundle.py --checks E7-kappa --out ..\qtc-kappa-check
```

既存の `checks.json` を読むこと、SHAが一致すること、数値を再計算して一致すること、仮説が合格することは別の確認です。速度閾値に不合格があっても、保存された結果の監査は合格し得ます。

### 3. 実験を最初から再計算する

**参照用の展開物とは別の作業コピーを作り**、各段のREADMEと最新の引き継ぎに従って実行します。全条件の再計時は今回の納品時にはやり直していません。K12だけでも元の実行では約64分かかっており、全系列の再実行時間は未見積もりです。

旧スクリプトを隔離モードで実行するための補助入口：

```powershell
# 別コピーのルートで。例：小モデルの既存selfcheckを実行
py -3.12 -I -B -S scripts/qtc_repro/run_script.py outputs/eqtc-depth-placement-lab/run.py --selfcheck
```

`run_script.py`はスクリプトのフォルダーと同梱依存をimport先に加えるだけで、判定規則を変更しません。元スクリプトに書込処理がある場合は、その処理を実行します。

- E0〜E5：各段のREADMEに従い、新しい作業コピーで計測してください。旧CLIの監査は`checks.json`を上書きするため、保存版では上記の共通検証入口を使います。
- E6/E7：各段の`reproduce.py`・`run.py --out <新しい名前>`とREADMEを参照してください。既存の観測フォルダーに上書きしない構成です。
- κ研究：各`k*/run.py`が宣言・依存ソースのハッシュを確認し、`results/`が既存なら拒否します。作業コピー内だけで旧`results/`を別名へ退避し、対象の`run.py`と`judge.py`を実行します。失敗したK1/K4/K6/K10は、修正版K1b/K4b/K6b/K10bと区別してください。
- 再計時：他の重い計算を止めた状態で、固定した入力・規則・単一スレッド設定を維持して実行します。絶対秒数の一致は保証しません。新しい測定として保存します。

同梱バイナリーはWindows/CPython 3.12用です。他OS・Python版では、別コピーで対応する数値依存を用意する必要があり、この配布での動作検証対象外です。PDFや旧SVGレポートを再生成する場合は追加でReportLab 4.4.9が必要です。保存HTML/SVGの閲覧と上記の数値検証には不要です。

ブラウザーQA用の一部スクリプトには作者環境のChrome/Playwrightへの絶対パスがあります。別機での自動QAには設定変更が必要です。元ソースのハッシュを保つため、今回の配布では書き換えていません。

## 指標の読み方と、残っている問い

`E = (p−p_ref)ᵀA(p−p_ref)`は、条件をそろえた速度のM重み誤差に対応します。通常の残差二乗や、相対発散とは異なる評価です。最新研究の`W = ‖r_new‖²−‖r_18‖²`は正なら残差二乗が増えた意味です。`κ`は比なので分母が小さい所で巨大化し、巨大なκだけでは実害の大きさを判断できません。

各段の定義、符号、単位、境界条件、参照残差を参照してください。静的投影の誤差から長時間の体積減少・散逸・不安定性を断定しません。

未解決事項には、段差スピル係数の理論値、入力族で相互作用の換算係数が違う理由、RSEの種別間結合の近似誤差、前処理の最悪例があります。[引き継ぎ](outputs/eqtc-e7-kappa-map/引き継ぎ.md)に次回の候補と再開コマンドを保存しています。**今回は新しい研究へ進まず、測定・判定・保存を終えて待機しています。**

## 配布を作り直す場合

`scripts/qtc_repro/catalog.py`が対象フォルダーを明示します。`build_bundle.py`は既存成果物を変更せず、新しいZIPへ固定順序・固定日時で収録し、全ファイルのmanifestとZIPのSHA-256を作ります。既存のZIPは上書きしません。

```powershell
py -3.12 -I -B -S scripts/qtc_repro/build_bundle.py --root . --numpy-site .\.eqtc-e4-deps --out ..\qtc-rebuilt.zip
```

配布ZIPからの再梱包ではNumPyも`.eqtc-e4-deps`にあるため上記指定を使います。開発環境では`--numpy-site`にNumPy 2.3.5とその`.libs`・`.dist-info`のあるフォルダーを指定します。OS・圧縮実装が違う場合のZIPバイト一致は検証していません。データの同一性はmanifestとSHAで確認してください。

---

## 最新検証の要点（原文）

出典：`docs/QTC-最新検証.md`（リンクだけ一体化資料の位置に合わせて補正）

# QTC / EQTC 最新検証の要点

2026-10-24 JST。Claude が完了した `outputs/eqtc-e7-kappa-map/` の第2区切り（K1〜K17）をまとめます。一次資料は[κ地図研究レポート](outputs/eqtc-e7-kappa-map/κ地図研究レポート.md)と各段の宣言・結果・判定JSONです。[引き継ぎ](outputs/eqtc-e7-kappa-map/引き継ぎ.md)には停止時の状態、再開方法、未解決事項があります。実行ログは経過・失敗を追う参考資料で、結論の根拠には宣言と保存結果を優先します。

## 検証した範囲

対象は、32×32×48級の格子を使った**静的な単発の圧力投影の代理実験**です。原QTC全体、水平四分木、時間発展、自由表面の移動、実用的な流体シミュレーション全体の優位性は検証していません。

誤差エネルギーは `E = (p − p_ref)ᵀ A (p − p_ref)`、発散変化は `W = ‖r_new‖² − ‖r_old‖²` です。EとWは別の量です。入れ子の空間を正確にGalerkin求解したとき、k=0のEは非増ですが、WやJacobi補正後の順位には同じ保証がありません。厳密な恒等式、事前宣言による判定、宣言のない探索は区別します。

## 4種類の速度測定

同じ機械、単一スレッドBLAS、順序をシャッフルした7ラウンドです。各ケースで同じラウンド内の時間比を取り、その中央値で判定しています。下表の中央値・範囲はケースごとの値をまとめたものです。信頼区間や他の機械での速度保証ではありません。比が小さいほど短時間です。

| 段階・測定対象 | 保存結果の時間比 | 宣言した判定と結果 |
|---|---|---|
| **K7：縮約系の解法**。縮約行列の組立て（新規時）、解法の準備・求解・補間。P構築や全工程は含まない | y余弦解法 / E7のCG：新規 **0.421**（0.324〜0.506）、再利用 **0.035**（0.030〜0.055） | 新規≤0.5を全件で満たすT1は**不合格**。再利用≤0.1のT2と品質同一性T3は**合格** |
| **K10b：全工程**。格子・右辺・基底・求解・Jacobi・速度復元・確認を毎回準備 | fast_mid / e7_mid：k0 **0.463**、k8 **0.480**、最大0.557。fast_ic / fast_mid：中央値約1.00、最大1.131 | 全件≤0.5のT1、IC追加コスト≤1.10のT2は**不合格**。複製CGのビット一致Q1、y余弦版の数値一致Q2、未使用入力での品質改善Q3は**合格** |
| **K13：一般の底の平底前処理CG**。縮約行列組立て・前処理準備・求解・補間 | flat_pcg / E7のCG：新規 **0.649**（0.511〜0.916）、再利用 **0.374**（0.226〜0.726） | 新規≤0.7のT1、再利用≤0.6のT4は全件では**不合格**。反復数≤1/4のT2と品質同一性T3は**合格** |
| **K16：二段RSEの全工程**。top18を求解→RSEで節点を選択→再求解 | rse2 / e7_mid：k8 **0.711**（0.573〜0.755）。rse2 / fast_mid：中央値 **1.47** | 時間≤0.8のR1、E改善率≥75%のR2、追加コスト≤2.2のR3は**すべて合格** |

品質・適用範囲の補足：

- **K7・K10b**：y余弦解法は、底と列種別ごとの節点がy方向に一様で、各列の節点数が等しい場合に使えます。K7の縮約残差は最大4.7e-13。K10bの複製CGは12入力すべてビット一致し、y余弦版の圧力の相対差は最大2.3e-12でした。IC節点は未使用8入力中7入力でk8のEを改善しました。元のK10は参照解に使う格子の誤りで停止し、修正を宣言した**K10b**が正式な結果です。
- **K13**：step・platform・terracesで検証。反復はE7の346〜373回から27〜85回へ減りました。最悪のterraces・bulk・IC配置では新規時間比0.916で、反復削減が同率の時間短縮になるわけではありません。LU解とのAノルム差は最大2.2e-11です。
- **K16**：k8のEは8入力中7入力で改善し、E比の中央値は**0.581**（surface 0.420、bulk 0.842）。幾何ごとの表の事前計算**約3.5秒は時計の外**です。参照解の計算も計時外です。K10bとK16ではE7の絶対時間が異なるため、段階をまたぐ絶対時間の差を高速化量にせず、各測定内の比を使います。

出典：本文§11.4と、[K7判定](outputs/eqtc-e7-kappa-map/k7_reduced_solve/results/judgement.json)、[K10b判定](outputs/eqtc-e7-kappa-map/k10b_pipeline/results/judgement.json)、[K13判定](outputs/eqtc-e7-kappa-map/k13_flat_precond/results/judgement.json)、[K16判定](outputs/eqtc-e7-kappa-map/k16_rse_pipeline/results/judgement.json)。各JSONの`verdicts`が合否、`rows`がケース別の値です。K16の時計外の表は`tables_s`にあります。

## W予測・相互作用・節点選択の成果

- **Wの合成予測（K11・K17）**：遮蔽付きモード和、深い側の独立列モデルIC、段差の縁のスピル項を足すモデルです。K11の新条件28件で相関**0.969**、傾き**1.03**。係数を合わせ直さずplatform・terracesへ移したK17では、合算の相関**0.926**、傾き**0.905**、相対RMS **0.383**、符号一致**97.5%**で、3予測が合格しました。terraces単独ではICのみのRMSが合成より小さく、全条件で合成が最良という結果ではありません。スピル係数`c ≈ 0.0281`は経験値です。
- **列種別間の相互作用（K5・K5b）**：developmentのU字型の相互作用は、調べた条件では段差の隣接2列に局在しました。基準解がそこに残す残差で順位を予測でき、未使用seedでSpearman相関はsurface **0.938**、bulk **0.857**。ただし換算係数は族で約8倍違い、bulkの比例帯予測は不合格です。
- **参照解を使わないRSE節点選択（K14・K15）**：基準の粗い解の残差と遮蔽Schur近似を使います。K14の新入力36件では、探索したoracleとのEの差が5%以内の入力が**88.9%**、選択時間の最大は**2.5ms**で5予測が合格。一般の底へ移したK15も4予測が合格し、oracleとの差の中央値はplatform **2.7%**、terraces **1.5%**でした。ただし5%を超えた入力は25%あり、terracesのoracleは座標降下2周による近似です。

出典：本文§7〜§11と、[K11判定](outputs/eqtc-e7-kappa-map/k11_w_composite/results/judgement.json)、[K5b結果](outputs/eqtc-e7-kappa-map/k5b_step_pool/results/k5b.json)、[K14判定](outputs/eqtc-e7-kappa-map/k14_rse_placement/results/judgement.json)、[K15判定](outputs/eqtc-e7-kappa-map/k15_rse_general/results/judgement.json)、[K17判定](outputs/eqtc-e7-kappa-map/k17_w_general/results/judgement.json)。

## 残る問題と旧結論の扱い

- スピル係数の理論的導出、浅い段差でモデルが外れる理由、相互作用の換算係数が入力族で違う理由は未解明です。
- RSEは底の値ごとの結合を近似しており、oracleとの差が残る例があります。平底前処理の代用列の選び方も未解決です。
- 固定した幾何中点が19層より常に良いわけではありません。入力の位相を動かした追試では、中点のEが19層の約1.05倍になる条件がありました。「既知4入力で節点を±4セルずらしても優位」という古い結果から、入力一般への優位は言えません。
- 「底0列は位相を追わない」は最新のκ研究で訂正されています。底0列も約0.9セル/セルで追い、以前の+8という値には掃引範囲の端での頭打ちが含まれます。「Jacobiで悪化が消えるのは高周波だから」という旧解釈も追試で否定されています。

訂正の経緯は[位相機構追試の訂正表](outputs/eqtc-e7-phase-mechanism/00_訂正表.md)、[追試レポート](outputs/eqtc-e7-phase-mechanism/E7追試レポート.md)、最新本文§0の「前回の解釈の訂正」を参照してください。古いレポートは当時の記録として残されています。

## 保存と再検証

第2区切りの測定・判定後に作業は停止しています。[新規コピーでの検証記録](outputs/eqtc-e7-kappa-map/verification/fresh_copy_verify_report.json)は`all_ok=true`で、280ファイルのチェックサム不一致0、20段の宣言と依存ハッシュの一致、選定した数値の独立再計算、図の再生成一致を記録しています。これは保存物の整合性の検証であり、すべての研究仮説の合格や、すべての計算を再実行したことを意味しません。

再検証は**新しいコピー**の`outputs/eqtc-e7-kappa-map/`で実行します。Python 3.12、NumPy 2.3.5、SciPy 1.16.3、PyAMG 5.3.0を使い、依存は祖先の`.eqtc-e4-deps`または環境変数`EQTC_DEPS`で指定します。

```text
python -I -B verify_bundle.py report.json
```

再計時する場合は、新しいコピーで既存の`results/`を退避し、対象段のフォルダーで`python -I -B run.py`、続いて`python -I -B judge.py`を実行します。既存の保存結果は上書きせず、4測定は一件ずつ実行します。詳しい条件と失敗履歴は各段の`declaration.json`、`FAILED.md`、[引き継ぎ](outputs/eqtc-e7-kappa-map/引き継ぎ.md)にあります。

---

## 再開情報と未解決事項（原文）

出典：`outputs/eqtc-e7-kappa-map/引き継ぎ.md`（リンクだけ一体化資料の位置に合わせて補正）

# 引き継ぎメモ（κ地図研究）— 第2区切りで作業を停止

最終更新：2026-10-24 JST（作業の日付）。依頼により、計時の4段（K7・K10/K10b・K13・K16）の測定と判定を終えた時点で研究作業を止めました。
**実行中・未完了の計算はありません**。この研究の Python プロセスは残っていません。他のツール（room サーバー、codex の bridge）の python.exe は常駐しており、計時の間も常駐していました。研究上の未決着（§4）と、実行上の中断（§2 の FAILED 記録）を分けて書きます。

本文：`κ地図研究レポート.md`（§00 が最新のまとめ、§11 が計時と一般の底）。

## 1. 実行環境と共通の規則
- Python：`C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`（3.12.14、numpy 2.3.5）。scipy 1.16.3 と pyamg 5.3.0 は、ワークスペースの `.eqtc-e4-deps` を `lib/common.py` が自動で読み込みます（別の場所なら環境変数 `EQTC_DEPS`）。
- 実行は常に `python -I -B <script>` です（キャッシュを作らない）。
- 各段の `run.py` は、宣言（`declaration.json`）・`declaration.sha256`・ハッシュで結ばれたファイルのどれかが一致しない場合と、`results/` が既にある場合は実行を拒否します（結果を上書きしない）。
- 計時の段は、他の計算と同時に走らせないでください。

## 2. 段の状態（すべて完了。未実行の段はありません）

| 段 | 状態 | 宣言 SHA-256 | 結果 |
|---|---|---|---|
| k1_verify1d | 不合格（FAILED_NOTES.md） | 318c26b4107bf6dd1ed14d50fdc492e1ebd6b4d16059484367ee81983524145e | results/verify1d.json |
| k1b_verify1d | 合格 13/13 | 0446eae5b5656f4e026b7a5500c5440bb30d2640f8d4b235637da89525717512 | results/verify1d.json |
| k2a_1dmap | 記述（宣言なし、厳密値） | — | results/map1d.json、figures/ |
| k2_ic_heldout | 位相・波長・広い包絡は合格、区間長・狭い包絡は不合格 | 45ab1c6a38c77d463737d789ed0d571f8c9d05aaa6bfd31b088dd4591bc900fc | results/k2.json、judgement.json（judge_save.py で保存） |
| k4_phase_linear | 保存時に停止（FAILED.md、未観測） | 92fc67033b48eaf71dd3c822d413d6cc981148f8ce1abe0b754da82072f927f5 | — |
| k4b_phase_linear | 合格 3/3 | fa01226f77264c3eec6418c85124635714a0195a3418d41d29895a7ff51087a0 | results/phase_linear.json |
| k5_dev_interaction | 局在は合格、P5.4 は不合格 | 40342330215ca1433055ebbdd675accf87fc1968a4c4c72f393b3893d6504039 | results/k5.json |
| k5b_step_pool | 順位・局在は合格、比例帯（bulk）は不合格 | 0f416b61e5289c681c83b50f58d8f342c1b70205ea9b7068aa12ab449e00f24c | results/k5b.json |
| k6_placement | 入力組立てで停止（FAILED.md、未観測） | 8f71923f24105f1191ff5102ef86008791d28198b523b5adaac173736ed1832e | — |
| k6b_placement | D1, D2, D4 は合格、D3 は不合格、D5 = H_mismatch | 2fe453740b37a835a4209641a5b5eebe7a697a59f5278e51d0d4684c51a60050 | results/k6.json、judgement.json |
| k7_reduced_solve（計時） | T2, T3 は合格、T1 は不合格（最大 0.506） | a740c26600816c634aede35ae49d93282cad10b8762f5d63daff87fea35ea31d | results/k7.json、judgement.json |
| k8_dof_budget | P8.1 = H_collective、P8.2(random) は合格、P8.2(b)・P8.3 は不合格 | 5eacf78f6759bb805c55c188c1875a13c94f5630fc7a3efb629a957e6dae5549 | results/k8.json、judgement.json |
| k10_pipeline（計時） | 参照解の格子の誤りで停止（FAILED.md、未観測） | c063aa99be9aad6e92d600a2aa47be8702ceca3400ec78ad38d1f780a9ea845f | — |
| k10b_pipeline（計時） | Q1, Q2, Q3 は合格、T1, T2 は不合格 | c7bdfe01ce04efe18b39dff14dbfaad19af96bf281d5610a69e4c69ebf7b7f14 | results/k10.json、judgement.json |
| k11_w_composite | 合格 3/3 | 165f168de9cd8aa13534294def575edd048a76a65e110abe32ff716c92a1b62d | results/k11.json、judgement.json |
| k12_general_beds | D1, D2, D4 は合格、D3 は不合格 | b2e3d2840522f1d9d589ce7d0b0e36161f30575cd0266e9b05bb693f245ed799 | results/k12.json、judgement.json |
| k13_flat_precond（計時） | T2, T3 は合格、T1, T4 は不合格 | 17ac9b718c5e8967d8600b680954768bdc9bc864fb1265f6ad5437a80d8d4eff | results/k13.json、judgement.json |
| k14_rse_placement | 合格 5/5、H_flat_only は棄却 | d6047af72e33080a44af240d9e33dbfbb727518b39b1cf03c8d427787b18a42a | results/k14.json、judgement.json |
| k15_rse_general | 合格 4/4（K12 の結果が出る前に凍結） | 8b89aa4cd5e9a9efc9f9a675990c071d64224cd41972f236f5d4ad487a8467e2 | results/k15.json、judgement.json |
| k16_rse_pipeline（計時） | 合格 3/3 | 6384e478f646edb79580b66f4585c42cf6641398395c270b201bcb6d827fc6bf | results/k16.json、judgement.json |
| k17_w_general | 合格 3/3、H_single_step は棄却 | 5f2287c3a9432b8b7dcf5edcab941f80b30fa45c8bd080c0c083086b2660a2c5 | results/k17.json、judgement.json |
| explore/e01〜e17 | 宣言なしの探索 | — | explore/*.json、*.log |

- 各段のフォルダーには、`declaration.json`・`declaration.sha256`・`run.py`・`judge.py`（あるもの）・`run.log`・`judge.log`・`results/` があります。
- 補足：
  - K10b の `judge.py` は、凍結の後・実行の前に書きました（結果は見ていません）。
  - K2 の判定値は `judge.py` が出力しましたが、保存時に停止したため `judge_save.py` で保存しました。
  - K4b は、保存の後の表示だけで停止しました（PRINT_CRASH_NOTE.txt）。

## 3. 必要なファイル
- `vendor/`：E7/E5 のソースの byte コピー（mesh, basis, solvers, inputs, e6_run）。`provenance-copies.txt` に元ファイルとの SHA-256 一致があります。
- `data/inputs`・`data/references`：E7 の入力と参照解。`data/prev`：前回段の結果の byte コピー。
- `lib/`：
  - `col1d`（1列の厳密な更新式）、`k3d`・`kmap`（3D と IC）、`wpredict`（W の合成予測）
  - `placement`（IC）、`placement_res`（RIC）、`rse`・`rse_fast`（RSE）
  - `redsolve`（縮約系の解法・y 余弦の厳密解法）、`flatprec`（平底前処理）、`fastp`（ベクトル化した P）
  - `svgheat`・`svgplot`（図）、`jsonsafe`、`freeze`
- `figures/make_figs.py`・`figures/make_figs_design.py`：保存JSONだけから図を再生成します。`k2a_1dmap/map1d.py` は 1D 地図です。
- `SHA256SUMS.txt`（`make_sums.py` で生成）、`verify_bundle.py`（検証）。

## 4. 再開コマンド（例。作業フォルダーで）
```
set PY=C:\Users\yauki\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe
%PY% -I -B verify_bundle.py report.json        （新しいコピーで実行。SHA・宣言・独立再計算・図）
cd k14_rse_placement && %PY% -I -B judge.py    （保存結果からの判定の再実行。どの段でも同様）
cd figures && %PY% -I -B make_figs.py && %PY% -I -B make_figs_design.py
```
- 段を最初から再実行するときは、その段の `results/` を別名に退避してから `python -I -B run.py` を実行します。宣言とソースが変わっていれば実行は拒否されます。
- 新しい段は、`lib/freeze.py <段のフォルダー> <draft.json>` で宣言を凍結してから実行します。

## 5. 未解決事項（研究上）
1. スピル係数 c ≈ 0.028（≈ 0.9h）の理論値。単純な「ハット形状の不一致」の見積もりでは約 6h になり、合いません。e12 で底 ≤ 6 だけ比が外れた理由も未解明です。
2. 列種別間の相互作用の換算係数が、surface と bulk で約8倍違う理由。「取り除ける部分」の仮説を定量化すること。
3. RSE の近似（底の値ごとに独立に評価し、種別間の結合を無視している）による誤り。K14 の bulk の1件、e16 の 20%、K15 で 5% を超えた 25%。
4. 平底前処理の代用列の選び方。K13 の terraces で反復 85 回・0.916 になった最悪例。
5. K17 の terraces で、IC だけの W 予測が合成よりわずかに良かった理由。
6. 底0列の追従のずれ（3D 5〜8 対 RSE 4〜8）。両種別を同時にずらしたときの 1.75 の分解。
7. 時間発展、原 QTC の水平四分木、Lightward、図書館は扱っていません（保留）。

## 6. 次回の候補（優先度の高い順の提案。今回は実行していません）
1. **種別間の結合を含む RSE**：y に一様な底では、y モードごとの x 方向の小さな Schur 行列で、厳密な捕捉エネルギーを計算できるはずです。上の3を解消し、オラクルとの差が残る入力で比べます。
2. **代用行列の選び方の改良**：底の値ごとの平均や面積で重み付けした代用列、二層の代用行列などを試し、K13 の最悪例で反復と時間を比べます（計時は単独で実行）。
3. **スピル係数 c の導出**：y モードに縮約した x–z 段差問題で、段差角の自己項と交差項を解析し、c と b12 依存を予測します。
4. **再利用の場面の評価**：形状が固定で入力がゆっくり変わる連続投影で、y 余弦の再利用（0.035倍）と RSE の節点選択をどれだけ使い回せるかを調べます。
5. 相互作用の換算係数（上の2）と、底0列の追従（上の6）の追試。

## 7. 保存内容の確認（作業停止時）
- 新しいコピー（ワークスペースの外、一時フォルダー）で `verify_bundle.py` を実行しました。**all_ok = True** でした。
  - SHA256SUMS の 280 ファイルがすべて一致しました。
  - 20 段の宣言とハッシュの結び付きがすべて保たれていました。
  - 保存結果の独立な再計算（K1b, K2, K4b, K5, K6b, K7, K11, K14）は 5e-14 以内で一致しました。
  - 図と1D地図の 21 ファイルを再生成し、byte 単位で一致しました。
  - `__pycache__` は作られていません。
- 記録：`verification/fresh_copy_verify_report.json`、`verification/fresh_copy_verify_stdout.txt`。その後、この記録を含めて SHA256SUMS.txt を作り直しました。
